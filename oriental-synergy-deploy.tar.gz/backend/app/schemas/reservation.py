"""
予約スキーマ
"""
from pydantic import BaseModel
from typing import Optional
from datetime import datetime
from ..models.reservation import ReservationStatus


class ReservationBase(BaseModel):
    """予約基本スキーマ"""
    company_id: int
    office_name: str
    office_address: Optional[str] = None
    reservation_date: str  # YYYY/MM/DD
    start_time: str  # HH:MM
    end_time: str  # HH:MM
    staff_names: Optional[str] = None
    employee_names: Optional[str] = None
    status: ReservationStatus = ReservationStatus.PENDING
    notes: Optional[str] = None
    requirements: Optional[str] = None


class ReservationCreate(ReservationBase):
    """予約作成スキーマ"""
    pass


class ReservationUpdate(BaseModel):
    """予約更新スキーマ"""
    office_name: Optional[str] = None
    office_address: Optional[str] = None
    reservation_date: Optional[str] = None
    start_time: Optional[str] = None
    end_time: Optional[str] = None
    staff_names: Optional[str] = None
    employee_names: Optional[str] = None
    status: Optional[ReservationStatus] = None
    notes: Optional[str] = None
    requirements: Optional[str] = None


class Reservation(ReservationBase):
    """予約レスポンススキーマ"""
    id: int
    created_at: datetime
    updated_at: datetime
    
    class Config:
        from_attributes = True




