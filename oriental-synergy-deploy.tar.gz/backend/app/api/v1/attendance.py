"""
勤怠管理API
"""
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List, Optional
from datetime import datetime
from ...database import get_db
from ...models.attendance import Attendance as AttendanceModel
from ...models.user import User, UserRole
from ...schemas.attendance import (
    Attendance,
    AttendanceCreate,
    AttendanceUpdate,
    ClockInRequest,
    ClockOutRequest
)
from ..deps import get_current_active_user, get_admin_user

router = APIRouter()


@router.post("/attendance/clock-in", response_model=Attendance, status_code=status.HTTP_201_CREATED)
def clock_in(
    request: ClockInRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """
    出勤打刻
    
    Args:
        request: 出勤打刻リクエスト
        db: データベースセッション
        current_user: 現在のユーザー
        
    Returns:
        Attendance: 作成された勤怠記録
    """
    # 同日の勤怠記録が既に存在するかチェック
    existing = db.query(AttendanceModel).filter(
        AttendanceModel.staff_id == request.staff_id,
        AttendanceModel.work_date == request.work_date,
        AttendanceModel.clock_out_time == None
    ).first()
    
    if existing:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="既に出勤打刻が記録されています"
        )
    
    # 出勤打刻を記録
    attendance = AttendanceModel(
        staff_id=request.staff_id,
        reservation_id=request.reservation_id,
        work_date=request.work_date,
        clock_in_time=datetime.utcnow(),
        location_in=request.location
    )
    
    db.add(attendance)
    db.commit()
    db.refresh(attendance)
    return attendance


@router.post("/attendance/clock-out", response_model=Attendance)
def clock_out(
    request: ClockOutRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """
    退勤打刻
    
    Args:
        request: 退勤打刻リクエスト
        db: データベースセッション
        current_user: 現在のユーザー
        
    Returns:
        Attendance: 更新された勤怠記録
    """
    # 勤怠記録を取得
    attendance = db.query(AttendanceModel).filter(
        AttendanceModel.id == request.attendance_id
    ).first()
    
    if not attendance:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="勤怠記録が見つかりません"
        )
    
    if attendance.clock_out_time:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="既に退勤打刻が記録されています"
        )
    
    # 退勤打刻を記録
    attendance.clock_out_time = datetime.utcnow()
    attendance.location_out = request.location
    attendance.break_minutes = request.break_minutes
    
    # 実働時間を計算（分）
    if attendance.clock_in_time and attendance.clock_out_time:
        total_minutes = int((attendance.clock_out_time - attendance.clock_in_time).total_seconds() / 60)
        attendance.work_hours = total_minutes - request.break_minutes
    
    db.commit()
    db.refresh(attendance)
    return attendance


@router.get("/attendance", response_model=List[Attendance])
def get_attendance_list(
    skip: int = 0,
    limit: int = 100,
    staff_id: Optional[int] = None,
    work_date: Optional[str] = None,
    is_approved: Optional[bool] = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """
    勤怠一覧を取得
    
    Args:
        skip: スキップする件数
        limit: 取得する最大件数
        staff_id: スタッフIDフィルター
        work_date: 勤務日フィルター
        is_approved: 承認済みフィルター
        db: データベースセッション
        current_user: 現在のユーザー
        
    Returns:
        List[Attendance]: 勤怠のリスト
    """
    query = db.query(AttendanceModel)
    
    # フィルター
    if staff_id:
        query = query.filter(AttendanceModel.staff_id == staff_id)
    
    if work_date:
        query = query.filter(AttendanceModel.work_date == work_date)
    
    if is_approved is not None:
        query = query.filter(AttendanceModel.is_approved == is_approved)
    
    attendance_list = query.offset(skip).limit(limit).all()
    return attendance_list


@router.get("/attendance/{attendance_id}", response_model=Attendance)
def get_attendance(
    attendance_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """
    勤怠詳細を取得
    
    Args:
        attendance_id: 勤怠ID
        db: データベースセッション
        current_user: 現在のユーザー
        
    Returns:
        Attendance: 勤怠情報
        
    Raises:
        HTTPException: 勤怠が見つからない場合
    """
    attendance = db.query(AttendanceModel).filter(
        AttendanceModel.id == attendance_id
    ).first()
    
    if not attendance:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="勤怠記録が見つかりません"
        )
    
    return attendance


@router.put("/attendance/{attendance_id}", response_model=Attendance)
def update_attendance(
    attendance_id: int,
    attendance_update: AttendanceUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_admin_user)
):
    """
    勤怠情報を更新（管理者のみ）
    
    Args:
        attendance_id: 勤怠ID
        attendance_update: 更新する勤怠情報
        db: データベースセッション
        current_user: 現在のユーザー（管理者権限必須）
        
    Returns:
        Attendance: 更新された勤怠
        
    Raises:
        HTTPException: 勤怠が見つからない場合
    """
    attendance = db.query(AttendanceModel).filter(
        AttendanceModel.id == attendance_id
    ).first()
    
    if not attendance:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="勤怠記録が見つかりません"
        )
    
    # 更新
    update_data = attendance_update.model_dump(exclude_unset=True)
    for key, value in update_data.items():
        setattr(attendance, key, value)
    
    # 承認処理
    if update_data.get("is_approved") and not attendance.approved_at:
        attendance.approved_by = current_user.id
        attendance.approved_at = datetime.utcnow()
    
    db.commit()
    db.refresh(attendance)
    return attendance


@router.post("/attendance/{attendance_id}/approve", response_model=Attendance)
def approve_attendance(
    attendance_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_admin_user)
):
    """
    勤怠を承認（管理者のみ）
    
    Args:
        attendance_id: 勤怠ID
        db: データベースセッション
        current_user: 現在のユーザー（管理者権限必須）
        
    Returns:
        Attendance: 承認された勤怠
        
    Raises:
        HTTPException: 勤怠が見つからない場合
    """
    attendance = db.query(AttendanceModel).filter(
        AttendanceModel.id == attendance_id
    ).first()
    
    if not attendance:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="勤怠記録が見つかりません"
        )
    
    if attendance.is_approved:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="既に承認済みです"
        )
    
    # 承認
    attendance.is_approved = True
    attendance.approved_by = current_user.id
    attendance.approved_at = datetime.utcnow()
    
    db.commit()
    db.refresh(attendance)
    return attendance


@router.delete("/attendance/{attendance_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_attendance(
    attendance_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_admin_user)
):
    """
    勤怠を削除（管理者のみ）
    
    Args:
        attendance_id: 勤怠ID
        db: データベースセッション
        current_user: 現在のユーザー（管理者権限必須）
        
    Raises:
        HTTPException: 勤怠が見つからない場合
    """
    attendance = db.query(AttendanceModel).filter(
        AttendanceModel.id == attendance_id
    ).first()
    
    if not attendance:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="勤怠記録が見つかりません"
        )
    
    db.delete(attendance)
    db.commit()
    return None

