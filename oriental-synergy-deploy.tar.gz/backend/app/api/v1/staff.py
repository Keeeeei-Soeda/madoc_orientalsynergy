"""
スタッフ管理API
"""
from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session
from typing import List, Optional
from ...database import get_db
from ...models.staff import Staff as StaffModel
from ...models.user import User
from ...schemas.staff import Staff, StaffCreate, StaffUpdate
from ..deps import get_current_active_user, get_admin_user

router = APIRouter()


@router.get("/staff", response_model=List[Staff])
def get_staff_list(
    skip: int = 0,
    limit: int = 100,
    is_available: Optional[bool] = None,
    search: Optional[str] = Query(None, description="名前で検索"),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """
    スタッフ一覧を取得
    
    Args:
        skip: スキップする件数
        limit: 取得する最大件数
        is_available: 稼働可能フィルター
        search: 検索キーワード（名前）
        db: データベースセッション
        current_user: 現在のユーザー
        
    Returns:
        List[Staff]: スタッフのリスト
    """
    query = db.query(StaffModel)
    
    # フィルター
    if is_available is not None:
        query = query.filter(StaffModel.is_available == is_available)
    
    if search:
        query = query.filter(StaffModel.name.contains(search))
    
    staff = query.offset(skip).limit(limit).all()
    return staff


@router.get("/staff/{staff_id}", response_model=Staff)
def get_staff(
    staff_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """
    スタッフ詳細を取得
    
    Args:
        staff_id: スタッフID
        db: データベースセッション
        current_user: 現在のユーザー
        
    Returns:
        Staff: スタッフ情報
        
    Raises:
        HTTPException: スタッフが見つからない場合
    """
    staff = db.query(StaffModel).filter(StaffModel.id == staff_id).first()
    if staff is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Staff with id {staff_id} not found"
        )
    return staff


@router.post("/staff", response_model=Staff, status_code=status.HTTP_201_CREATED)
def create_staff(
    staff: StaffCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_admin_user)
):
    """
    スタッフを作成（管理者のみ）
    
    Args:
        staff: 作成するスタッフ情報
        db: データベースセッション
        current_user: 現在のユーザー（管理者権限必須）
        
    Returns:
        Staff: 作成されたスタッフ
        
    Raises:
        HTTPException: LINE IDが既に存在する場合
    """
    # LINE IDの重複チェック
    if staff.line_id:
        existing_staff = db.query(StaffModel).filter(
            StaffModel.line_id == staff.line_id
        ).first()
        if existing_staff:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="LINE ID already registered"
            )
    
    db_staff = StaffModel(**staff.model_dump())
    db.add(db_staff)
    db.commit()
    db.refresh(db_staff)
    return db_staff


@router.put("/staff/{staff_id}", response_model=Staff)
def update_staff(
    staff_id: int,
    staff: StaffUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_admin_user)
):
    """
    スタッフ情報を更新（管理者のみ）
    
    Args:
        staff_id: スタッフID
        staff: 更新するスタッフ情報
        db: データベースセッション
        current_user: 現在のユーザー（管理者権限必須）
        
    Returns:
        Staff: 更新されたスタッフ
        
    Raises:
        HTTPException: スタッフが見つからない場合
    """
    db_staff = db.query(StaffModel).filter(StaffModel.id == staff_id).first()
    if db_staff is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Staff with id {staff_id} not found"
        )
    
    # 更新
    update_data = staff.model_dump(exclude_unset=True)
    for key, value in update_data.items():
        setattr(db_staff, key, value)
    
    db.commit()
    db.refresh(db_staff)
    return db_staff


@router.delete("/staff/{staff_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_staff(
    staff_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_admin_user)
):
    """
    スタッフを削除（管理者のみ）
    
    Args:
        staff_id: スタッフID
        db: データベースセッション
        current_user: 現在のユーザー（管理者権限必須）
        
    Raises:
        HTTPException: スタッフが見つからない場合
    """
    db_staff = db.query(StaffModel).filter(StaffModel.id == staff_id).first()
    if db_staff is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Staff with id {staff_id} not found"
        )
    
    db.delete(db_staff)
    db.commit()
    return None

