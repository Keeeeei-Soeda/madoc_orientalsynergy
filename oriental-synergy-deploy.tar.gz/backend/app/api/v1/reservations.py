"""
予約管理API
"""
from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session
from typing import List, Optional
from ...database import get_db
from ...models.reservation import Reservation as ReservationModel, ReservationStatus
from ...models.user import User
from ...schemas.reservation import Reservation, ReservationCreate, ReservationUpdate
from ..deps import get_current_active_user, get_company_user

router = APIRouter()


@router.get("/reservations", response_model=List[Reservation])
def get_reservations(
    skip: int = 0,
    limit: int = 100,
    status: Optional[ReservationStatus] = None,
    company_id: Optional[int] = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """
    予約一覧を取得
    
    Args:
        skip: スキップする件数
        limit: 取得する最大件数
        status: ステータスフィルター
        company_id: 企業IDフィルター
        db: データベースセッション
        current_user: 現在のユーザー
        
    Returns:
        List[Reservation]: 予約のリスト
    """
    query = db.query(ReservationModel)
    
    # フィルター
    if status:
        query = query.filter(ReservationModel.status == status)
    
    if company_id:
        query = query.filter(ReservationModel.company_id == company_id)
    
    reservations = query.offset(skip).limit(limit).all()
    return reservations


@router.get("/reservations/{reservation_id}", response_model=Reservation)
def get_reservation(
    reservation_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """
    予約詳細を取得
    
    Args:
        reservation_id: 予約ID
        db: データベースセッション
        current_user: 現在のユーザー
        
    Returns:
        Reservation: 予約情報
        
    Raises:
        HTTPException: 予約が見つからない場合
    """
    reservation = db.query(ReservationModel).filter(
        ReservationModel.id == reservation_id
    ).first()
    
    if reservation is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Reservation with id {reservation_id} not found"
        )
    return reservation


@router.post("/reservations", response_model=Reservation, status_code=status.HTTP_201_CREATED)
def create_reservation(
    reservation: ReservationCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_company_user)
):
    """
    予約を作成（企業または管理者のみ）
    
    Args:
        reservation: 作成する予約情報
        db: データベースセッション
        current_user: 現在のユーザー（企業または管理者権限必須）
        
    Returns:
        Reservation: 作成された予約
    """
    db_reservation = ReservationModel(**reservation.model_dump())
    db.add(db_reservation)
    db.commit()
    db.refresh(db_reservation)
    return db_reservation


@router.put("/reservations/{reservation_id}", response_model=Reservation)
def update_reservation(
    reservation_id: int,
    reservation: ReservationUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_company_user)
):
    """
    予約情報を更新（企業または管理者のみ）
    
    Args:
        reservation_id: 予約ID
        reservation: 更新する予約情報
        db: データベースセッション
        current_user: 現在のユーザー（企業または管理者権限必須）
        
    Returns:
        Reservation: 更新された予約
        
    Raises:
        HTTPException: 予約が見つからない場合
    """
    db_reservation = db.query(ReservationModel).filter(
        ReservationModel.id == reservation_id
    ).first()
    
    if db_reservation is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Reservation with id {reservation_id} not found"
        )
    
    # 更新
    update_data = reservation.model_dump(exclude_unset=True)
    for key, value in update_data.items():
        setattr(db_reservation, key, value)
    
    db.commit()
    db.refresh(db_reservation)
    return db_reservation


@router.delete("/reservations/{reservation_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_reservation(
    reservation_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_company_user)
):
    """
    予約を削除（企業または管理者のみ）
    
    Args:
        reservation_id: 予約ID
        db: データベースセッション
        current_user: 現在のユーザー（企業または管理者権限必須）
        
    Raises:
        HTTPException: 予約が見つからない場合
    """
    db_reservation = db.query(ReservationModel).filter(
        ReservationModel.id == reservation_id
    ).first()
    
    if db_reservation is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Reservation with id {reservation_id} not found"
        )
    
    db.delete(db_reservation)
    db.commit()
    return None




