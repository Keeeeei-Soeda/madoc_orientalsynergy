"""
勤怠モデル
"""
from sqlalchemy import Column, Integer, String, DateTime, ForeignKey, Text, Boolean
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship
from ..database import Base


class Attendance(Base):
    """勤怠テーブル"""
    __tablename__ = "attendance"
    
    id = Column(Integer, primary_key=True, index=True)
    staff_id = Column(Integer, ForeignKey("staff.id"), nullable=False)
    reservation_id = Column(Integer, ForeignKey("reservations.id"), nullable=True)
    work_date = Column(String(50), nullable=False)  # 2025/10/30
    clock_in_time = Column(DateTime(timezone=True))
    clock_out_time = Column(DateTime(timezone=True))
    break_minutes = Column(Integer, default=0)  # 休憩時間（分）
    work_hours = Column(Integer)  # 実働時間（分）
    location_in = Column(String(255))  # 出勤打刻位置
    location_out = Column(String(255))  # 退勤打刻位置
    notes = Column(Text)
    is_approved = Column(Boolean, default=False)  # 承認済みフラグ
    approved_by = Column(Integer, ForeignKey("users.id"))  # 承認者ID
    approved_at = Column(DateTime(timezone=True))  # 承認日時
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())
    
    # リレーション
    staff = relationship("Staff", backref="attendances")
    reservation = relationship("Reservation", backref="attendances")
    
    def __repr__(self):
        return f"<Attendance(id={self.id}, staff_id={self.staff_id}, date={self.work_date})>"

