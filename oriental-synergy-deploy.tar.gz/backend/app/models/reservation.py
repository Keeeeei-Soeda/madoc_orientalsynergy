"""
予約モデル
"""
from sqlalchemy import Column, Integer, String, DateTime, ForeignKey, Enum as SQLEnum, Text
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship
from ..database import Base
import enum


class ReservationStatus(str, enum.Enum):
    """予約ステータス"""
    PENDING = "pending"        # 未確認
    CONFIRMED = "confirmed"    # 確定
    COMPLETED = "completed"    # 完了
    CANCELLED = "cancelled"    # キャンセル
    EVALUATED = "evaluated"    # 評価済み


class Reservation(Base):
    """予約テーブル"""
    __tablename__ = "reservations"
    
    id = Column(Integer, primary_key=True, index=True)
    company_id = Column(Integer, ForeignKey("companies.id"), nullable=False)
    office_name = Column(String(255), nullable=False)
    office_address = Column(Text)
    reservation_date = Column(String(50), nullable=False)  # 2025/10/30
    start_time = Column(String(10), nullable=False)  # 15:00
    end_time = Column(String(10), nullable=False)    # 17:00
    staff_names = Column(Text)  # カンマ区切り
    employee_names = Column(Text)  # カンマ区切り
    status = Column(SQLEnum(ReservationStatus), default=ReservationStatus.PENDING, nullable=False)
    notes = Column(Text)
    requirements = Column(Text)  # 要望など
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())
    
    # リレーション
    company = relationship("Company", backref="reservations")
    
    def __repr__(self):
        return f"<Reservation(id={self.id}, company_id={self.company_id}, date={self.reservation_date})>"




