import React from 'react'
import StaffSidebar from '@/components/layout/StaffSidebar'
import Header from '@/components/layout/Header'
import Footer from '@/components/layout/Footer'

export default function StaffLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <div className="admin-layout">
      <StaffSidebar />
      <div className="main-wrapper">
        <Header />
        <main className="main-content">
          {children}
        </main>
        <Footer />
      </div>
    </div>
  )
}

