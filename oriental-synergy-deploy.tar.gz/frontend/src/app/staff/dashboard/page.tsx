'use client'

import React from 'react'
import PageHeader from '@/components/common/PageHeader'
import StatCard from '@/components/common/StatCard'
import Link from 'next/link'

// モックデータ
const statsData = [
  { title: '今月の勤務日数', value: 8, icon: 'bi-calendar-check', iconColor: 'primary' },
  { title: '今月の収入予定', value: '¥240,000', icon: 'bi-currency-yen', iconColor: 'success' },
  { title: '新しいオファー', value: 3, icon: 'bi-envelope-heart', iconColor: 'warning', change: '要確認', changeType: 'warning' as const },
  { title: '平均評価', value: '4.8', icon: 'bi-star-fill', iconColor: 'info' },
]

const upcomingShifts = [
  { id: '1', company: '株式会社A', office: '梅田営業所', date: '2025/01/05', time: '15:00～17:00', status: 'confirmed' },
  { id: '2', company: '株式会社B', office: '難波営業所', date: '2025/01/08', time: '10:00～12:00', status: 'confirmed' },
  { id: '3', company: '株式会社C', office: '梅田営業所', date: '2025/01/10', time: '14:00～16:00', status: 'pending' },
]

const recentOffers = [
  { id: '1', company: '株式会社D', date: '2025/01/12', time: '15:00～17:00', pay: '¥15,000' },
  { id: '2', company: '株式会社E', date: '2025/01/15', time: '10:00～12:00', pay: '¥12,000' },
  { id: '3', company: '株式会社F', date: '2025/01/18', time: '14:00～16:00', pay: '¥13,500' },
]

export default function StaffDashboardPage() {
  return (
    <>
      <PageHeader title="ダッシュボード" />
      
      {/* 統計カード */}
      <div className="row g-3 mb-4">
        {statsData.map((stat, index) => (
          <div key={index} className="col-12 col-sm-6 col-xl-3">
            <StatCard {...stat} />
          </div>
        ))}
      </div>
      
      <div className="row g-4">
        {/* 今後のシフト */}
        <div className="col-12 col-xl-8">
          <div className="card">
            <div className="card-header d-flex justify-content-between align-items-center">
              <h5 className="mb-0">今後のシフト</h5>
              <Link href="/staff/shifts" className="btn btn-sm btn-outline-success">
                すべて表示
              </Link>
            </div>
            <div className="card-body p-0">
              <div className="table-responsive">
                <table className="table table-hover mb-0">
                  <thead>
                    <tr>
                      <th>日時</th>
                      <th>企業</th>
                      <th>事業所</th>
                      <th>時間</th>
                      <th>ステータス</th>
                    </tr>
                  </thead>
                  <tbody>
                    {upcomingShifts.map((shift) => (
                      <tr key={shift.id}>
                        <td className="fw-bold">{shift.date}</td>
                        <td>{shift.company}</td>
                        <td>{shift.office}</td>
                        <td>{shift.time}</td>
                        <td>
                          <span className={`badge bg-${shift.status === 'pending' ? 'warning' : 'success'}`}>
                            {shift.status === 'pending' ? '未確定' : '確定'}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
        
        {/* 新しいオファー */}
        <div className="col-12 col-xl-4">
          <div className="card">
            <div className="card-header d-flex justify-content-between align-items-center">
              <h5 className="mb-0">
                新しいオファー
                <span className="badge bg-danger ms-2">3</span>
              </h5>
              <Link href="/staff/jobs/offers" className="btn btn-sm btn-outline-success">
                すべて表示
              </Link>
            </div>
            <div className="card-body">
              <div className="d-flex flex-column gap-3">
                {recentOffers.map((offer) => (
                  <div key={offer.id} className="border-bottom pb-3">
                    <div className="d-flex justify-content-between align-items-center mb-2">
                      <div className="fw-bold">{offer.company}</div>
                      <div className="text-success fw-bold">{offer.pay}</div>
                    </div>
                    <div className="text-muted small mb-2">
                      <i className="bi bi-calendar3 me-1"></i>
                      {offer.date} {offer.time}
                    </div>
                    <div className="d-flex gap-2">
                      <button className="btn btn-sm btn-success">受諾</button>
                      <button className="btn btn-sm btn-outline-secondary">辞退</button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
        
        {/* クイックアクション */}
        <div className="col-12">
          <div className="card">
            <div className="card-header">
              <h5 className="mb-0">クイックアクション</h5>
            </div>
            <div className="card-body">
              <div className="row g-3">
                <div className="col-6 col-md-3">
                  <Link href="/staff/jobs" className="btn btn-outline-primary w-100">
                    <i className="bi bi-briefcase me-2"></i>
                    業務一覧
                  </Link>
                </div>
                <div className="col-6 col-md-3">
                  <Link href="/staff/mypage" className="btn btn-outline-success w-100">
                    <i className="bi bi-person-circle me-2"></i>
                    マイページ
                  </Link>
                </div>
                <div className="col-6 col-md-3">
                  <Link href="/staff/attendance" className="btn btn-outline-info w-100">
                    <i className="bi bi-clock-history me-2"></i>
                    勤怠管理
                  </Link>
                </div>
                <div className="col-6 col-md-3">
                  <Link href="/staff/evaluations" className="btn btn-outline-warning w-100">
                    <i className="bi bi-star me-2"></i>
                    評価確認
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  )
}

