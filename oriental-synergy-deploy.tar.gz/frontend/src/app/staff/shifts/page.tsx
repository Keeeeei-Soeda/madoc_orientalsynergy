'use client'

import React, { useState } from 'react'
import PageHeader from '@/components/common/PageHeader'

// モックデータ
const shiftsData = [
  { 
    id: '1', 
    company: '株式会社A', 
    office: '梅田営業所', 
    date: '2025/01/05',
    dayOfWeek: '日',
    startTime: '15:00',
    endTime: '17:00',
    status: 'confirmed',
    employees: ['田中一郎', '佐藤二朗'],
    notes: '通常業務'
  },
  { 
    id: '2', 
    company: '株式会社B', 
    office: '難波営業所', 
    date: '2025/01/08',
    dayOfWeek: '水',
    startTime: '10:00',
    endTime: '12:00',
    status: 'confirmed',
    employees: ['鈴木三郎'],
    notes: ''
  },
  { 
    id: '3', 
    company: '株式会社C', 
    office: '梅田営業所', 
    date: '2025/01/10',
    dayOfWeek: '金',
    startTime: '14:00',
    endTime: '16:00',
    status: 'pending',
    employees: ['未定'],
    notes: '初めての事業所です'
  },
  { 
    id: '4', 
    company: '株式会社A', 
    office: '梅田営業所', 
    date: '2024/12/20',
    dayOfWeek: '金',
    startTime: '15:00',
    endTime: '17:00',
    status: 'completed',
    employees: ['田中一郎'],
    notes: '通常業務',
    actualStart: '14:55',
    actualEnd: '17:05'
  },
]

const statusConfig = {
  confirmed: { label: '確定', color: 'success' },
  pending: { label: '未確定', color: 'warning' },
  completed: { label: '完了', color: 'secondary' },
  cancelled: { label: 'キャンセル', color: 'danger' },
}

export default function StaffShiftsPage() {
  const [viewMode, setViewMode] = useState<'list' | 'calendar'>('list')
  const [filterStatus, setFilterStatus] = useState('all')
  
  const filteredShifts = shiftsData.filter(shift => 
    filterStatus === 'all' || shift.status === filterStatus
  )
  
  return (
    <>
      <PageHeader 
        title="シフト管理"
        breadcrumbs={[
          { label: 'ダッシュボード', href: '/staff/dashboard' },
          { label: 'シフト管理' }
        ]}
      />
      
      {/* 表示切替とフィルター */}
      <div className="card mb-4">
        <div className="card-body">
          <div className="row g-3 align-items-center">
            <div className="col-12 col-md-6">
              <div className="btn-group" role="group">
                <button 
                  type="button" 
                  className={`btn ${viewMode === 'list' ? 'btn-primary' : 'btn-outline-primary'}`}
                  onClick={() => setViewMode('list')}
                >
                  <i className="bi bi-list-ul me-2"></i>
                  リスト表示
                </button>
                <button 
                  type="button" 
                  className={`btn ${viewMode === 'calendar' ? 'btn-primary' : 'btn-outline-primary'}`}
                  onClick={() => setViewMode('calendar')}
                >
                  <i className="bi bi-calendar3 me-2"></i>
                  カレンダー表示
                </button>
              </div>
            </div>
            <div className="col-12 col-md-6">
              <select 
                className="form-select"
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value)}
              >
                <option value="all">すべてのステータス</option>
                <option value="confirmed">確定</option>
                <option value="pending">未確定</option>
                <option value="completed">完了</option>
                <option value="cancelled">キャンセル</option>
              </select>
            </div>
          </div>
        </div>
      </div>
      
      {/* シフト一覧（リスト表示） */}
      {viewMode === 'list' && (
        <div className="card">
          <div className="card-header">
            <h5 className="mb-0">シフト一覧 ({filteredShifts.length}件)</h5>
          </div>
          <div className="card-body p-0">
            <div className="table-responsive">
              <table className="table table-hover mb-0">
                <thead>
                  <tr>
                    <th>日時</th>
                    <th>企業</th>
                    <th>事業所</th>
                    <th>時間</th>
                    <th>対応社員</th>
                    <th>ステータス</th>
                    <th>アクション</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredShifts.map((shift) => {
                    const config = statusConfig[shift.status as keyof typeof statusConfig]
                    
                    return (
                      <tr key={shift.id}>
                        <td>
                          <div className="fw-bold">{shift.date}</div>
                          <small className="text-muted">({shift.dayOfWeek})</small>
                        </td>
                        <td>{shift.company}</td>
                        <td>{shift.office}</td>
                        <td>
                          <div>{shift.startTime} ～ {shift.endTime}</div>
                          {shift.status === 'completed' && shift.actualStart && (
                            <small className="text-success">
                              実績: {shift.actualStart} ～ {shift.actualEnd}
                            </small>
                          )}
                        </td>
                        <td>
                          {shift.employees.map((employee, i) => (
                            <span key={i} className="badge bg-secondary me-1">
                              {employee}
                            </span>
                          ))}
                        </td>
                        <td>
                          <span className={`badge bg-${config.color}`}>
                            {config.label}
                          </span>
                        </td>
                        <td>
                          <button className="btn btn-sm btn-outline-primary">
                            <i className="bi bi-eye"></i>
                          </button>
                        </td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
      
      {/* カレンダー表示（将来実装） */}
      {viewMode === 'calendar' && (
        <div className="card">
          <div className="card-body text-center py-5">
            <i className="bi bi-calendar3 fs-1 text-muted"></i>
            <p className="text-muted mt-3">カレンダー表示は今後実装予定です。</p>
          </div>
        </div>
      )}
    </>
  )
}

