'use client'

import React, { useState, useEffect } from 'react'
import PageHeader from '@/components/common/PageHeader'
import Link from 'next/link'
import { reservationsApi, Reservation } from '@/lib/api'

const statusConfig = {
  pending: { label: '募集中', color: 'success' },
  confirmed: { label: '確定', color: 'primary' },
  completed: { label: '完了', color: 'secondary' },
  cancelled: { label: 'キャンセル', color: 'danger' },
  evaluated: { label: '評価済み', color: 'info' },
}

export default function StaffJobsPage() {
  const [reservations, setReservations] = useState<Reservation[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [searchTerm, setSearchTerm] = useState('')
  const [statusFilter, setStatusFilter] = useState('all')
  
  // データ取得
  useEffect(() => {
    const fetchReservations = async () => {
      try {
        setLoading(true)
        // 全ての予約を取得（スタッフ視点では求人一覧）
        const data = await reservationsApi.getAll()
        setReservations(data)
      } catch (err) {
        setError(err instanceof Error ? err.message : '求人データの取得に失敗しました')
        console.error('求人データ取得エラー:', err)
      } finally {
        setLoading(false)
      }
    }
    
    fetchReservations()
  }, [])
  
  const filteredJobs = reservations.filter(reservation => {
    const matchesSearch = reservation.office_name.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesStatus = statusFilter === 'all' || reservation.status === statusFilter
    return matchesSearch && matchesStatus
  })
  
  // ローディング表示
  if (loading) {
    return (
      <>
        <PageHeader 
          title="業務一覧"
          breadcrumbs={[
            { label: 'ダッシュボード', href: '/staff/dashboard' },
            { label: '業務一覧' }
          ]}
        />
        <div className="text-center py-5">
          <div className="spinner-border text-primary" role="status">
            <span className="visually-hidden">読み込み中...</span>
          </div>
        </div>
      </>
    )
  }
  
  // エラー表示
  if (error) {
    return (
      <>
        <PageHeader 
          title="業務一覧"
          breadcrumbs={[
            { label: 'ダッシュボード', href: '/staff/dashboard' },
            { label: '業務一覧' }
          ]}
        />
        <div className="alert alert-danger" role="alert">
          <i className="bi bi-exclamation-triangle me-2"></i>
          {error}
        </div>
      </>
    )
  }
  
  return (
    <>
      <PageHeader 
        title="業務一覧"
        breadcrumbs={[
          { label: 'ダッシュボード', href: '/staff/dashboard' },
          { label: '業務一覧' }
        ]}
        action={
          <Link href="/staff/jobs/offers" className="btn btn-warning position-relative">
            <i className="bi bi-envelope-heart me-2"></i>
            オファー確認
            <span className="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
              0
            </span>
          </Link>
        }
      />
      
      {/* 検索とフィルター */}
      <div className="card mb-4">
        <div className="card-body">
          <div className="row g-3">
            <div className="col-12 col-md-8">
              <div className="search-bar">
                <i className="bi bi-search search-icon"></i>
                <input 
                  type="text" 
                  className="form-control" 
                  placeholder="事業所名で検索..." 
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
            </div>
            <div className="col-12 col-md-4">
              <select 
                className="form-select"
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
              >
                <option value="all">すべてのステータス</option>
                <option value="pending">募集中</option>
                <option value="confirmed">確定</option>
                <option value="completed">完了</option>
              </select>
            </div>
          </div>
        </div>
      </div>
      
      {/* 業務カード一覧 */}
      <div className="row g-4">
        {filteredJobs.map((job) => {
          const config = statusConfig[job.status as keyof typeof statusConfig]
          const startTime = job.start_time
          const endTime = job.end_time
          
          return (
            <div key={job.id} className="col-12 col-lg-6">
              <div className="card h-100">
                <div className="card-header d-flex justify-content-between align-items-center">
                  <div>
                    <h5 className="mb-0">{job.office_name}</h5>
                    <small className="text-muted">ID: {job.id}</small>
                  </div>
                  <span className={`badge bg-${config.color}`}>
                    {config.label}
                  </span>
                </div>
                <div className="card-body">
                  <div className="row g-3 mb-3">
                    <div className="col-6">
                      <div className="d-flex align-items-center gap-2">
                        <i className="bi bi-calendar3 text-primary"></i>
                        <div>
                          <small className="text-muted d-block">日時</small>
                          <div className="fw-bold">{job.reservation_date}</div>
                          <small>{startTime}〜{endTime}</small>
                        </div>
                      </div>
                    </div>
                    <div className="col-6">
                      <div className="d-flex align-items-center gap-2">
                        <i className="bi bi-people text-info"></i>
                        <div>
                          <small className="text-muted d-block">スタッフ</small>
                          <div className="fw-bold">{job.staff_names || '未アサイン'}</div>
                        </div>
                      </div>
                    </div>
                    <div className="col-12">
                      <div className="d-flex align-items-start gap-2">
                        <i className="bi bi-geo-alt text-info mt-1"></i>
                        <div>
                          <small className="text-muted d-block">場所</small>
                          <div>{job.office_address || '住所情報なし'}</div>
                        </div>
                      </div>
                    </div>
                    {job.requirements && (
                      <div className="col-12">
                        <div className="d-flex align-items-start gap-2">
                          <i className="bi bi-info-circle text-warning mt-1"></i>
                          <div>
                            <small className="text-muted d-block">要望</small>
                            <div>{job.requirements}</div>
                          </div>
                        </div>
                      </div>
                    )}
                    {job.notes && (
                      <div className="col-12">
                        <div className="d-flex align-items-start gap-2">
                          <i className="bi bi-chat-left-text text-secondary mt-1"></i>
                          <div>
                            <small className="text-muted d-block">備考</small>
                            <div>{job.notes}</div>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                  
                  <div className="d-flex gap-2">
                    {job.status === 'pending' && (
                      <>
                        <button className="btn btn-success flex-grow-1">
                          <i className="bi bi-check-circle me-2"></i>
                          応募する
                        </button>
                        <Link href={`/staff/jobs/${job.id}`} className="btn btn-outline-secondary">
                          詳細
                        </Link>
                      </>
                    )}
                    {job.status === 'confirmed' && (
                      <Link href={`/staff/jobs/${job.id}`} className="btn btn-primary w-100">
                        <i className="bi bi-eye me-2"></i>
                        詳細を見る
                      </Link>
                    )}
                    {job.status === 'completed' && (
                      <button className="btn btn-secondary w-100" disabled>
                        <i className="bi bi-check-circle me-2"></i>
                        完了
                      </button>
                    )}
                  </div>
                </div>
              </div>
            </div>
          )
        })}
      </div>
      
      {filteredJobs.length === 0 && (
        <div className="card">
          <div className="card-body text-center py-5">
            <i className="bi bi-inbox fs-1 text-muted"></i>
            <p className="text-muted mt-3">該当する業務が見つかりませんでした。</p>
          </div>
        </div>
      )}
    </>
  )
}

