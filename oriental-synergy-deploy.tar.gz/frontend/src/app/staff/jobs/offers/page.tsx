'use client'

import React, { useState } from 'react'
import PageHeader from '@/components/common/PageHeader'

// モックデータ
const offersData = [
  { 
    id: '1', 
    company: '株式会社A', 
    office: '梅田事業所', 
    address: '大阪府大阪市北区～～～',
    date: '2025/01/15', 
    time: '15:00～17:00',
    pay: '¥15,000',
    description: 'あん摩マッサージ施術',
    equipment: 'マッサージベッド、タオル完備',
    requirements: '資格: あん摩マッサージ指圧師',
    notes: '初めての事業所です。駐車場あり。',
    deadline: '2025/01/10',
    status: 'pending'
  },
  { 
    id: '2', 
    company: '株式会社B', 
    office: '難波営業所', 
    address: '大阪府大阪市中央区～～～',
    date: '2025/01/18', 
    time: '10:00～12:00',
    pay: '¥12,000',
    description: 'あん摩マッサージ施術（複数名対応）',
    equipment: 'マッサージチェア、タオル完備',
    requirements: '資格: あん摩マッサージ指圧師',
    notes: '複数の社員への施術になります。',
    deadline: '2025/01/13',
    status: 'pending'
  },
  { 
    id: '3', 
    company: '株式会社C', 
    office: '梅田営業所', 
    address: '大阪府大阪市北区～～～',
    date: '2025/01/20', 
    time: '14:00～16:00',
    pay: '¥13,500',
    description: 'あん摩マッサージ施術',
    equipment: 'マッサージベッド完備',
    requirements: '資格: あん摩マッサージ指圧師',
    notes: '定期契約先です。',
    deadline: '2025/01/15',
    status: 'pending'
  },
]

export default function StaffOffersPage() {
  const [selectedOffer, setSelectedOffer] = useState<typeof offersData[0] | null>(null)
  
  return (
    <>
      <PageHeader 
        title="オファー確認"
        breadcrumbs={[
          { label: 'ダッシュボード', href: '/staff/dashboard' },
          { label: '業務一覧', href: '/staff/jobs' },
          { label: 'オファー確認' }
        ]}
      />
      
      {/* オファー一覧 */}
      <div className="row g-4">
        {offersData.map((offer) => (
          <div key={offer.id} className="col-12 col-lg-6">
            <div className="card border-warning h-100">
              <div className="card-header bg-warning bg-opacity-10 d-flex justify-content-between align-items-center">
                <div>
                  <h5 className="mb-0 text-warning">
                    <i className="bi bi-envelope-heart me-2"></i>
                    新しいオファー
                  </h5>
                  <small className="text-muted">{offer.company}</small>
                </div>
                <span className="badge bg-danger">
                  <i className="bi bi-clock me-1"></i>
                  締切: {offer.deadline}
                </span>
              </div>
              <div className="card-body">
                <div className="mb-3">
                  <h6 className="fw-bold">{offer.office}</h6>
                  <p className="text-muted small mb-0">
                    <i className="bi bi-geo-alt me-1"></i>
                    {offer.address}
                  </p>
                </div>
                
                <div className="row g-3 mb-3">
                  <div className="col-6">
                    <div className="d-flex align-items-center gap-2">
                      <i className="bi bi-calendar3 text-primary"></i>
                      <div>
                        <small className="text-muted d-block">日時</small>
                        <div className="fw-bold">{offer.date}</div>
                        <small>{offer.time}</small>
                      </div>
                    </div>
                  </div>
                  <div className="col-6">
                    <div className="d-flex align-items-center gap-2">
                      <i className="bi bi-currency-yen text-success"></i>
                      <div>
                        <small className="text-muted d-block">報酬</small>
                        <div className="fw-bold text-success fs-5">{offer.pay}</div>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="mb-3">
                  <div className="border-start border-primary border-3 ps-3 mb-2">
                    <small className="text-muted">業務内容</small>
                    <p className="mb-0">{offer.description}</p>
                  </div>
                  <div className="border-start border-info border-3 ps-3">
                    <small className="text-muted">備品</small>
                    <p className="mb-0">{offer.equipment}</p>
                  </div>
                </div>
                
                <button 
                  className="btn btn-outline-secondary w-100 mb-2"
                  data-bs-toggle="modal"
                  data-bs-target="#offerDetailModal"
                  onClick={() => setSelectedOffer(offer)}
                >
                  <i className="bi bi-eye me-2"></i>
                  詳細を見る
                </button>
                
                <div className="d-flex gap-2">
                  <button className="btn btn-success flex-grow-1">
                    <i className="bi bi-check-circle me-2"></i>
                    受諾する
                  </button>
                  <button className="btn btn-outline-danger">
                    辞退
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
      
      {offersData.length === 0 && (
        <div className="card">
          <div className="card-body text-center py-5">
            <i className="bi bi-envelope-heart fs-1 text-muted"></i>
            <p className="text-muted mt-3">新しいオファーはありません。</p>
          </div>
        </div>
      )}
      
      {/* オファー詳細モーダル */}
      <div className="modal fade" id="offerDetailModal" tabIndex={-1}>
        <div className="modal-dialog modal-lg">
          <div className="modal-content">
            <div className="modal-header bg-warning bg-opacity-10">
              <h5 className="modal-title">
                <i className="bi bi-envelope-heart me-2 text-warning"></i>
                オファー詳細
              </h5>
              <button type="button" className="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div className="modal-body">
              {selectedOffer && (
                <>
                  <div className="row g-3 mb-4">
                    <div className="col-12">
                      <h6 className="text-muted mb-2">企業情報</h6>
                      <table className="table table-borderless">
                        <tbody>
                          <tr>
                            <th style={{ width: '30%' }}>企業名</th>
                            <td>{selectedOffer.company}</td>
                          </tr>
                          <tr>
                            <th>実施事業所</th>
                            <td>{selectedOffer.office}</td>
                          </tr>
                          <tr>
                            <th>住所</th>
                            <td>{selectedOffer.address}</td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                    
                    <div className="col-12">
                      <h6 className="text-muted mb-2">業務詳細</h6>
                      <table className="table table-borderless">
                        <tbody>
                          <tr>
                            <th style={{ width: '30%' }}>訪問日付</th>
                            <td>{selectedOffer.date}</td>
                          </tr>
                          <tr>
                            <th>訪問時間</th>
                            <td>{selectedOffer.time}</td>
                          </tr>
                          <tr>
                            <th>報酬</th>
                            <td className="text-success fw-bold fs-5">{selectedOffer.pay}</td>
                          </tr>
                          <tr>
                            <th>業務内容</th>
                            <td>{selectedOffer.description}</td>
                          </tr>
                          <tr>
                            <th>備品リスト</th>
                            <td>{selectedOffer.equipment}</td>
                          </tr>
                          <tr>
                            <th>必要資格</th>
                            <td><span className="badge bg-primary">{selectedOffer.requirements}</span></td>
                          </tr>
                          <tr>
                            <th>備考</th>
                            <td>{selectedOffer.notes}</td>
                          </tr>
                          <tr>
                            <th>応募締切</th>
                            <td>
                              <span className="badge bg-danger">
                                <i className="bi bi-clock me-1"></i>
                                {selectedOffer.deadline}
                              </span>
                            </td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>
                  
                  <div className="d-flex gap-2">
                    <button className="btn btn-success flex-grow-1" data-bs-dismiss="modal">
                      <i className="bi bi-check-circle me-2"></i>
                      受諾する
                    </button>
                    <button className="btn btn-outline-danger" data-bs-dismiss="modal">
                      辞退する
                    </button>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      </div>
    </>
  )
}

