'use client'

import React, { useState } from 'react'
import PageHeader from '@/components/common/PageHeader'

// モックデータ
const staffData = {
  name: '山田花子',
  address: '大阪府大阪市',
  phone: '090-1234-5678',
  email: 'yamada@example.com',
  lineId: 'yamada_line',
  bankAccount: '三菱UFJ銀行 梅田支店 普通 1234567',
  qualifications: 'あん摩マッサージ指圧師',
  availableDays: '月、火、水、金',
  notes: '土日は対応不可',
}

const evaluationsData = [
  { id: '22333', company: '株式会社A', office: '梅田事業所', startTime: '9:55', scheduledStart: '10:00', endTime: '18:10', scheduledEnd: '18:00', date: '2025/10/30', cleanliness: 5, responsiveness: 5, satisfaction: 5, comment: 'とても丁寧でした' },
  { id: '45566', company: '株式会社A', office: '難波事業所', startTime: '9:55', scheduledStart: '10:00', endTime: '18:10', scheduledEnd: '18:00', date: '2025/10/15', cleanliness: 5, responsiveness: 5, satisfaction: 5, comment: '素晴らしかったです' },
]

export default function StaffMypage() {
  const [isEditing, setIsEditing] = useState(false)
  const [selectedComment, setSelectedComment] = useState<string>('')
  
  return (
    <>
      <PageHeader 
        title="マイページ"
        breadcrumbs={[
          { label: 'ダッシュボード', href: '/staff/dashboard' },
          { label: 'マイページ' }
        ]}
      />
      
      <div className="row g-4">
        {/* 基本情報 */}
        <div className="col-12 col-xl-6">
          <div className="card">
            <div className="card-header d-flex justify-content-between align-items-center">
              <h5 className="mb-0">基本情報</h5>
              <button 
                className="btn btn-sm btn-primary"
                onClick={() => setIsEditing(!isEditing)}
              >
                <i className="bi bi-pencil me-2"></i>
                {isEditing ? '保存' : '編集'}
              </button>
            </div>
            <div className="card-body">
              <table className="table table-borderless mb-0">
                <tbody>
                  <tr>
                    <th style={{ width: '40%' }}>氏名</th>
                    <td>
                      {isEditing ? (
                        <input type="text" className="form-control form-control-sm" defaultValue={staffData.name} />
                      ) : (
                        staffData.name
                      )}
                    </td>
                  </tr>
                  <tr>
                    <th>住所</th>
                    <td>
                      {isEditing ? (
                        <input type="text" className="form-control form-control-sm" defaultValue={staffData.address} />
                      ) : (
                        staffData.address
                      )}
                    </td>
                  </tr>
                  <tr>
                    <th>電話番号</th>
                    <td>
                      {isEditing ? (
                        <input type="tel" className="form-control form-control-sm" defaultValue={staffData.phone} />
                      ) : (
                        staffData.phone
                      )}
                    </td>
                  </tr>
                  <tr>
                    <th>メールアドレス</th>
                    <td>
                      {isEditing ? (
                        <input type="email" className="form-control form-control-sm" defaultValue={staffData.email} />
                      ) : (
                        staffData.email
                      )}
                    </td>
                  </tr>
                  <tr>
                    <th>LINE ID</th>
                    <td>
                      <code className="text-success">{staffData.lineId}</code>
                    </td>
                  </tr>
                  <tr>
                    <th>銀行口座</th>
                    <td>
                      {isEditing ? (
                        <input type="text" className="form-control form-control-sm" defaultValue={staffData.bankAccount} />
                      ) : (
                        staffData.bankAccount
                      )}
                    </td>
                  </tr>
                  <tr>
                    <th>保有資格</th>
                    <td>
                      {isEditing ? (
                        <input type="text" className="form-control form-control-sm" defaultValue={staffData.qualifications} />
                      ) : (
                        <span className="badge bg-primary">{staffData.qualifications}</span>
                      )}
                    </td>
                  </tr>
                  <tr>
                    <th>稼働可能曜日</th>
                    <td>
                      {isEditing ? (
                        <input type="text" className="form-control form-control-sm" defaultValue={staffData.availableDays} />
                      ) : (
                        staffData.availableDays
                      )}
                    </td>
                  </tr>
                  <tr>
                    <th>備考</th>
                    <td>
                      {isEditing ? (
                        <textarea className="form-control form-control-sm" rows={2} defaultValue={staffData.notes}></textarea>
                      ) : (
                        staffData.notes
                      )}
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
        
        {/* 評価サマリー */}
        <div className="col-12 col-xl-6">
          <div className="card">
            <div className="card-header">
              <h5 className="mb-0">評価サマリー</h5>
            </div>
            <div className="card-body">
              <div className="row g-3 text-center">
                <div className="col-4">
                  <div className="border rounded p-3">
                    <div className="fs-2 fw-bold text-success">4.8</div>
                    <div className="text-muted small">総合評価</div>
                    <div className="text-warning">
                      <i className="bi bi-star-fill"></i>
                      <i className="bi bi-star-fill"></i>
                      <i className="bi bi-star-fill"></i>
                      <i className="bi bi-star-fill"></i>
                      <i className="bi bi-star-half"></i>
                    </div>
                  </div>
                </div>
                <div className="col-4">
                  <div className="border rounded p-3">
                    <div className="fs-2 fw-bold text-primary">48</div>
                    <div className="text-muted small">完了業務数</div>
                  </div>
                </div>
                <div className="col-4">
                  <div className="border rounded p-3">
                    <div className="fs-2 fw-bold text-info">12</div>
                    <div className="text-muted small">今月の業務</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        {/* 評価一覧 */}
        <div className="col-12">
          <div className="card">
            <div className="card-header">
              <h5 className="mb-0">評価一覧</h5>
            </div>
            <div className="card-body p-0">
              <div className="table-responsive">
                <table className="table table-hover mb-0">
                  <thead>
                    <tr>
                      <th>ID</th>
                      <th>顧客企業</th>
                      <th>実施事業所</th>
                      <th>出勤時間（予定）</th>
                      <th>退勤時間（打刻）</th>
                      <th>訪問日</th>
                      <th>清潔感</th>
                      <th>対応力</th>
                      <th>満足度</th>
                      <th>コメント</th>
                    </tr>
                  </thead>
                  <tbody>
                    {evaluationsData.map((evaluation) => (
                      <tr key={evaluation.id}>
                        <td className="fw-bold">{evaluation.id}</td>
                        <td>{evaluation.company}</td>
                        <td>{evaluation.office}</td>
                        <td>
                          {evaluation.startTime}
                          <small className="text-muted d-block">({evaluation.scheduledStart})</small>
                        </td>
                        <td>
                          {evaluation.endTime}
                          <small className="text-muted d-block">({evaluation.scheduledEnd})</small>
                        </td>
                        <td>{evaluation.date}</td>
                        <td>
                          <div className="text-warning">
                            {[...Array(evaluation.cleanliness)].map((_, i) => (
                              <i key={i} className="bi bi-star-fill"></i>
                            ))}
                          </div>
                        </td>
                        <td>
                          <div className="text-warning">
                            {[...Array(evaluation.responsiveness)].map((_, i) => (
                              <i key={i} className="bi bi-star-fill"></i>
                            ))}
                          </div>
                        </td>
                        <td>
                          <div className="text-warning">
                            {[...Array(evaluation.satisfaction)].map((_, i) => (
                              <i key={i} className="bi bi-star-fill"></i>
                            ))}
                          </div>
                        </td>
                        <td>
                          <button 
                            className="btn btn-sm btn-outline-success"
                            data-bs-toggle="modal"
                            data-bs-target="#commentModal"
                            onClick={() => setSelectedComment(evaluation.comment)}
                          >
                            <i className="bi bi-eye"></i>
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* コメントモーダル */}
      <div className="modal fade" id="commentModal" tabIndex={-1}>
        <div className="modal-dialog">
          <div className="modal-content">
            <div className="modal-header">
              <h5 className="modal-title">コメント</h5>
              <button type="button" className="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div className="modal-body">
              <p>{selectedComment}</p>
            </div>
            <div className="modal-footer">
              <button type="button" className="btn btn-secondary" data-bs-dismiss="modal">閉じる</button>
            </div>
          </div>
        </div>
      </div>
    </>
  )
}

