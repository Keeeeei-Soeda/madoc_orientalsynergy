'use client'

import React, { useState, useEffect } from 'react'
import Link from 'next/link'
import PageHeader from '@/components/common/PageHeader'
import { Reservation, getStatusLabel, getStatusBadgeClass } from '@/lib/api'

const statusConfig = {
  pending: { label: '未確認', color: 'warning' },
  confirmed: { label: '受付済', color: 'success' },
  completed: { label: '終了', color: 'secondary' },
  evaluated: { label: '評価済み', color: 'info' },
  cancelled: { label: 'キャンセル', color: 'danger' },
}

// モックデータ（認証機能実装までの仮データ）
const mockReservations: Reservation[] = [
  {
    id: 1,
    company_id: 1,
    office_name: '本社オフィス',
    office_address: '大阪府大阪市北区梅田1-1-1',
    reservation_date: '2026/01/15',
    start_time: '10:00',
    end_time: '12:00',
    staff_names: '山田花子, 佐藤美咲',
    employee_names: '田中部長, 鈴木課長',
    status: 'confirmed',
    notes: '定期契約',
    requirements: '2名派遣希望',
    created_at: '2026-01-01T00:00:00',
    updated_at: '2026-01-01T00:00:00',
  },
  {
    id: 2,
    company_id: 1,
    office_name: '本社オフィス',
    office_address: '大阪府大阪市北区梅田1-1-1',
    reservation_date: '2026/01/20',
    start_time: '14:00',
    end_time: '16:00',
    staff_names: '鈴木健太',
    employee_names: '佐藤主任',
    status: 'confirmed',
    notes: '定期契約',
    requirements: '1名派遣希望',
    created_at: '2026-01-02T00:00:00',
    updated_at: '2026-01-02T00:00:00',
  },
  {
    id: 4,
    company_id: 1,
    office_name: '本社オフィス',
    office_address: '大阪府大阪市北区梅田1-1-1',
    reservation_date: '2025/12/20',
    start_time: '10:00',
    end_time: '12:00',
    staff_names: '山田花子, 佐藤美咲',
    employee_names: '田中部長, 鈴木課長',
    status: 'completed',
    notes: '完了済み',
    requirements: '2名派遣希望',
    created_at: '2025-12-10T00:00:00',
    updated_at: '2025-12-20T00:00:00',
  },
]

export default function CompanyReservationsPage() {
  const [reservations, setReservations] = useState<Reservation[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [searchTerm, setSearchTerm] = useState('')
  
  // TODO: 実際のログインユーザーのcompany_idを取得する
  const companyId = 1 // 仮の企業ID
  
  // データ取得（モックデータを使用）
  useEffect(() => {
    // 認証機能実装までは、モックデータを表示
    setTimeout(() => {
      setReservations(mockReservations)
      setLoading(false)
    }, 500)
    
    /* API連携版（認証実装後に使用）
    const fetchReservations = async () => {
      try {
        setLoading(true)
        const data = await reservationsApi.getAll({ company_id: companyId })
        setReservations(data)
      } catch (err) {
        setError(err instanceof Error ? err.message : '予約データの取得に失敗しました')
        console.error('予約データ取得エラー:', err)
      } finally {
        setLoading(false)
      }
    }
    fetchReservations()
    */
  }, [companyId])
  
  const filteredReservations = reservations.filter(reservation =>
    reservation.office_name.toLowerCase().includes(searchTerm.toLowerCase())
  )
  
  // ローディング表示
  if (loading) {
    return (
      <>
        <PageHeader 
          title="予約管理" 
          breadcrumbs={[
            { label: 'ダッシュボード', href: '/company/dashboard' },
            { label: '予約管理' }
          ]}
        />
        <div className="text-center py-5">
          <div className="spinner-border text-primary" role="status">
            <span className="visually-hidden">読み込み中...</span>
          </div>
        </div>
      </>
    )
  }
  
  // エラー表示
  if (error) {
    return (
      <>
        <PageHeader 
          title="予約管理" 
          breadcrumbs={[
            { label: 'ダッシュボード', href: '/company/dashboard' },
            { label: '予約管理' }
          ]}
        />
        <div className="alert alert-danger" role="alert">
          <i className="bi bi-exclamation-triangle me-2"></i>
          {error}
        </div>
      </>
    )
  }
  
  return (
    <>
      <PageHeader 
        title="予約管理" 
        breadcrumbs={[
          { label: 'ダッシュボード', href: '/company/dashboard' },
          { label: '予約管理' }
        ]}
        action={
          <Link href="/company/reservations/new" className="btn btn-primary">
            <i className="bi bi-plus-circle me-2"></i>
            新規予約
          </Link>
        }
      />
      
      {/* 検索 */}
      <div className="card mb-4">
        <div className="card-body">
          <div className="search-bar">
            <i className="bi bi-search search-icon"></i>
            <input 
              type="text" 
              className="form-control" 
              placeholder="事業所名で検索..." 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>
      </div>
      
      {/* 予約一覧 */}
      <div className="card">
        <div className="card-header">
          <h5 className="mb-0">予約一覧 ({filteredReservations.length}件)</h5>
        </div>
        <div className="card-body p-0">
          <div className="table-responsive">
            <table className="table table-hover mb-0">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>実施事業所</th>
                  <th>事業所住所</th>
                  <th>訪問日付</th>
                  <th>スタッフ</th>
                  <th>社員</th>
                  <th>ステータス</th>
                  <th>アクション</th>
                </tr>
              </thead>
              <tbody>
                {filteredReservations.map((reservation) => {
                  const config = statusConfig[reservation.status as keyof typeof statusConfig]
                  
                  return (
                    <tr key={reservation.id}>
                      <td className="fw-bold">{reservation.id}</td>
                      <td>{reservation.office_name}</td>
                      <td>
                        <small className="text-muted">{reservation.office_address}</small>
                      </td>
                      <td>
                        <div>{reservation.reservation_date}</div>
                        <small className="text-muted">{reservation.start_time}〜{reservation.end_time}</small>
                      </td>
                      <td>{reservation.staff_names || '未定'}</td>
                      <td>{reservation.employee_names || '未定'}</td>
                      <td>
                        <span className={`badge bg-${config.color}`}>
                          {config.label}
                        </span>
                      </td>
                      <td>
                        <div className="btn-group btn-group-sm">
                          {reservation.status === 'pending' && (
                            <button className="btn btn-primary">
                              <i className="bi bi-megaphone me-1"></i>
                              募集
                            </button>
                          )}
                          <Link href={`/company/reservations/${reservation.id}`} className="btn btn-outline-success">
                            <i className="bi bi-eye me-1"></i>
                            確認
                          </Link>
                          {reservation.status === 'completed' && (
                            <Link href={`/company/evaluations/${reservation.id}`} className="btn btn-danger">
                              <i className="bi bi-star me-1"></i>
                              評価入力
                            </Link>
                          )}
                          {reservation.status === 'evaluated' && (
                            <button className="btn btn-secondary" disabled>
                              <i className="bi bi-check-circle me-1"></i>
                              評価済み
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </>
  )
}

