'use client'

import React, { useState, useEffect } from 'react'
import { useParams, useRouter } from 'next/navigation'
import Link from 'next/link'
import PageHeader from '@/components/common/PageHeader'
import { reservationsApi, Reservation, getStatusLabel } from '@/lib/api'

const statusConfig = {
  pending: { label: '未確認', color: 'warning' },
  confirmed: { label: '受付済', color: 'success' },
  completed: { label: '終了', color: 'secondary' },
  evaluated: { label: '評価済み', color: 'info' },
  cancelled: { label: 'キャンセル', color: 'danger' },
}

export default function CompanyReservationDetailPage() {
  const params = useParams()
  const router = useRouter()
  const reservationId = parseInt(params.id as string)
  
  const [reservation, setReservation] = useState<Reservation | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  
  // データ取得
  useEffect(() => {
    const fetchReservation = async () => {
      try {
        setLoading(true)
        const data = await reservationsApi.getById(reservationId)
        setReservation(data)
      } catch (err) {
        setError(err instanceof Error ? err.message : '予約データの取得に失敗しました')
        console.error('予約データ取得エラー:', err)
      } finally {
        setLoading(false)
      }
    }
    
    if (reservationId) {
      fetchReservation()
    }
  }, [reservationId])
  
  // キャンセル処理
  const handleCancel = async () => {
    if (!confirm('この予約をキャンセルしてもよろしいですか？')) {
      return
    }
    
    try {
      const updated = await reservationsApi.update(reservationId, { 
        status: 'cancelled' as any 
      })
      setReservation(updated)
      alert('予約をキャンセルしました')
    } catch (err) {
      alert('キャンセルに失敗しました: ' + (err instanceof Error ? err.message : ''))
    }
  }
  
  // ローディング表示
  if (loading) {
    return (
      <>
        <PageHeader 
          title="予約詳細" 
          breadcrumbs={[
            { label: 'ダッシュボード', href: '/company/dashboard' },
            { label: '予約管理', href: '/company/reservations' },
            { label: '予約詳細' }
          ]}
        />
        <div className="text-center py-5">
          <div className="spinner-border text-primary" role="status">
            <span className="visually-hidden">読み込み中...</span>
          </div>
        </div>
      </>
    )
  }
  
  // エラー表示
  if (error || !reservation) {
    return (
      <>
        <PageHeader 
          title="予約詳細" 
          breadcrumbs={[
            { label: 'ダッシュボード', href: '/company/dashboard' },
            { label: '予約管理', href: '/company/reservations' },
            { label: '予約詳細' }
          ]}
        />
        <div className="alert alert-danger" role="alert">
          <i className="bi bi-exclamation-triangle me-2"></i>
          {error || '予約が見つかりませんでした'}
        </div>
      </>
    )
  }
  
  const config = statusConfig[reservation.status as keyof typeof statusConfig]
  
  return (
    <>
      <PageHeader 
        title={`予約詳細 #${reservation.id}`}
        breadcrumbs={[
          { label: 'ダッシュボード', href: '/company/dashboard' },
          { label: '予約管理', href: '/company/reservations' },
          { label: `予約 #${reservation.id}` }
        ]}
        action={
          <div className="d-flex gap-2">
            {reservation.status === 'completed' && (
              <Link 
                href={`/company/evaluations/${reservation.id}`}
                className="btn btn-warning"
              >
                <i className="bi bi-star me-2"></i>
                評価を入力
              </Link>
            )}
            {(reservation.status === 'pending' || reservation.status === 'confirmed') && (
              <button 
                onClick={handleCancel}
                className="btn btn-outline-danger"
              >
                <i className="bi bi-x-circle me-2"></i>
                キャンセル
              </button>
            )}
          </div>
        }
      />
      
      <div className="row g-4">
        {/* 基本情報 */}
        <div className="col-12 col-lg-8">
          <div className="card mb-4">
            <div className="card-header">
              <h5 className="mb-0">予約情報</h5>
            </div>
            <div className="card-body">
              <div className="row g-3">
                <div className="col-12">
                  <div className="d-flex justify-content-between align-items-center mb-3 pb-3 border-bottom">
                    <h4 className="mb-0">{reservation.office_name}</h4>
                    <span className={`badge bg-${config.color} fs-6`}>
                      {config.label}
                    </span>
                  </div>
                </div>
                
                <div className="col-12">
                  <div className="d-flex align-items-start gap-3 mb-3">
                    <i className="bi bi-geo-alt-fill text-info fs-4"></i>
                    <div>
                      <label className="form-label text-muted mb-1">住所</label>
                      <p className="mb-0">{reservation.office_address || '未設定'}</p>
                    </div>
                  </div>
                </div>
                
                <div className="col-12 col-md-6">
                  <div className="d-flex align-items-start gap-3">
                    <i className="bi bi-calendar3 text-primary fs-4"></i>
                    <div>
                      <label className="form-label text-muted mb-1">訪問日</label>
                      <p className="mb-0 fw-bold fs-5">{reservation.reservation_date}</p>
                    </div>
                  </div>
                </div>
                
                <div className="col-12 col-md-6">
                  <div className="d-flex align-items-start gap-3">
                    <i className="bi bi-clock text-success fs-4"></i>
                    <div>
                      <label className="form-label text-muted mb-1">時間</label>
                      <p className="mb-0 fw-bold fs-5">
                        {reservation.start_time} 〜 {reservation.end_time}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          {/* スタッフ・社員情報 */}
          <div className="card mb-4">
            <div className="card-header">
              <h5 className="mb-0">担当スタッフ・対象社員</h5>
            </div>
            <div className="card-body">
              <div className="row g-3">
                <div className="col-12 col-md-6">
                  <div className="d-flex align-items-start gap-3">
                    <i className="bi bi-person-badge text-primary fs-4"></i>
                    <div className="flex-grow-1">
                      <label className="form-label text-muted mb-1">担当スタッフ</label>
                      {reservation.staff_names ? (
                        <div>
                          {reservation.staff_names.split(',').map((name, index) => (
                            <div key={index} className="badge bg-primary me-2 mb-2">
                              {name.trim()}
                            </div>
                          ))}
                        </div>
                      ) : (
                        <p className="text-muted mb-0">未定</p>
                      )}
                    </div>
                  </div>
                </div>
                
                <div className="col-12 col-md-6">
                  <div className="d-flex align-items-start gap-3">
                    <i className="bi bi-people text-info fs-4"></i>
                    <div className="flex-grow-1">
                      <label className="form-label text-muted mb-1">対象社員</label>
                      {reservation.employee_names ? (
                        <div>
                          {reservation.employee_names.split(',').map((name, index) => (
                            <div key={index} className="badge bg-info me-2 mb-2">
                              {name.trim()}
                            </div>
                          ))}
                        </div>
                      ) : (
                        <p className="text-muted mb-0">未定</p>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          {/* 要望・備考 */}
          <div className="card">
            <div className="card-header">
              <h5 className="mb-0">要望・備考</h5>
            </div>
            <div className="card-body">
              <div className="mb-3">
                <label className="form-label text-muted">要望</label>
                <p>{reservation.requirements || 'なし'}</p>
              </div>
              {reservation.notes && (
                <div>
                  <label className="form-label text-muted">備考</label>
                  <p>{reservation.notes}</p>
                </div>
              )}
            </div>
          </div>
        </div>
        
        {/* サイドバー */}
        <div className="col-12 col-lg-4">
          {/* アクション */}
          {reservation.status === 'pending' && (
            <div className="card mb-4 border-warning">
              <div className="card-body text-center">
                <i className="bi bi-hourglass-split text-warning fs-1 mb-3"></i>
                <h5 className="card-title">確認待ち</h5>
                <p className="text-muted">
                  管理者が確認中です。しばらくお待ちください。
                </p>
              </div>
            </div>
          )}
          
          {reservation.status === 'confirmed' && (
            <div className="card mb-4 border-success">
              <div className="card-body text-center">
                <i className="bi bi-check-circle text-success fs-1 mb-3"></i>
                <h5 className="card-title">予約確定</h5>
                <p className="text-muted">
                  予約が確定しました。当日をお待ちください。
                </p>
              </div>
            </div>
          )}
          
          {reservation.status === 'completed' && (
            <div className="card mb-4 border-info">
              <div className="card-body text-center">
                <i className="bi bi-star text-warning fs-1 mb-3"></i>
                <h5 className="card-title">評価をお願いします</h5>
                <p className="text-muted mb-3">
                  施術が完了しました。スタッフの評価をお願いします。
                </p>
                <Link 
                  href={`/company/evaluations/${reservation.id}`}
                  className="btn btn-warning w-100"
                >
                  <i className="bi bi-star me-2"></i>
                  評価を入力
                </Link>
              </div>
            </div>
          )}
          
          {/* 日時情報 */}
          <div className="card">
            <div className="card-header">
              <h6 className="mb-0">作成日時</h6>
            </div>
            <div className="card-body">
              <p className="small mb-0">
                {new Date(reservation.created_at).toLocaleString('ja-JP')}
              </p>
            </div>
          </div>
        </div>
      </div>
    </>
  )
}




