'use client'

import React, { useState } from 'react'
import PageHeader from '@/components/common/PageHeader'

// モックデータ
const employeesData = [
  { id: '1', name: '田中一郎', lineId: 'tanaka_line', department: '総務部', status: '連携済', position: '部長' },
  { id: '2', name: '佐藤二朗', lineId: 'sato_line', department: '人事部', status: '連携済', position: '課長' },
  { id: '3', name: '加藤三郎', lineId: '', department: '営業部', status: '未連携', position: '主任' },
  { id: '4', name: '鈴木四郎', lineId: 'suzuki_line', department: '総務部', status: '連携済', position: '一般' },
]

export default function CompanyEmployeesPage() {
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedEmployee, setSelectedEmployee] = useState<typeof employeesData[0] | null>(null)
  
  const filteredEmployees = employeesData.filter(employee =>
    employee.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    employee.department.toLowerCase().includes(searchTerm.toLowerCase())
  )
  
  return (
    <>
      <PageHeader 
        title="社員管理（LINE連動）"
        breadcrumbs={[
          { label: 'ダッシュボード', href: '/company/dashboard' },
          { label: '社員管理' }
        ]}
        action={
          <button className="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addEmployeeModal">
            <i className="bi bi-plus-circle me-2"></i>
            社員を追加
          </button>
        }
      />
      
      {/* 検索 */}
      <div className="card mb-4">
        <div className="card-body">
          <div className="search-bar">
            <i className="bi bi-search search-icon"></i>
            <input 
              type="text" 
              className="form-control" 
              placeholder="社員名または部署で検索..." 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>
      </div>
      
      {/* 社員一覧 */}
      <div className="card">
        <div className="card-header">
          <h5 className="mb-0">社員一覧 ({filteredEmployees.length}件)</h5>
        </div>
        <div className="card-body p-0">
          <div className="table-responsive">
            <table className="table table-hover mb-0">
              <thead>
                <tr>
                  <th>社員名</th>
                  <th>部署</th>
                  <th>役職</th>
                  <th>LINE ID</th>
                  <th>LINE連携状況</th>
                  <th>アクション</th>
                </tr>
              </thead>
              <tbody>
                {filteredEmployees.map((employee) => (
                  <tr key={employee.id}>
                    <td className="fw-bold">
                      <i className="bi bi-person-circle me-2 text-primary"></i>
                      {employee.name}
                    </td>
                    <td>{employee.department}</td>
                    <td>{employee.position}</td>
                    <td>
                      {employee.lineId ? (
                        <code className="text-success">{employee.lineId}</code>
                      ) : (
                        <span className="text-muted">-</span>
                      )}
                    </td>
                    <td>
                      {employee.status === '連携済' ? (
                        <span className="badge bg-success">
                          <i className="bi bi-check-circle me-1"></i>
                          連携済
                        </span>
                      ) : (
                        <span className="badge bg-warning">
                          <i className="bi bi-exclamation-circle me-1"></i>
                          未連携
                        </span>
                      )}
                    </td>
                    <td>
                      <div className="btn-group btn-group-sm">
                        <button 
                          className="btn btn-outline-primary"
                          data-bs-toggle="modal" 
                          data-bs-target="#employeeDetailModal"
                          onClick={() => setSelectedEmployee(employee)}
                        >
                          <i className="bi bi-eye"></i>
                        </button>
                        <button className="btn btn-outline-secondary">
                          <i className="bi bi-pencil"></i>
                        </button>
                        {employee.status === '未連携' && (
                          <button className="btn btn-success">
                            <i className="bi bi-line me-1"></i>
                            LINE招待
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
      
      {/* 社員詳細モーダル */}
      <div className="modal fade" id="employeeDetailModal" tabIndex={-1}>
        <div className="modal-dialog">
          <div className="modal-content">
            <div className="modal-header">
              <h5 className="modal-title">社員情報</h5>
              <button type="button" className="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div className="modal-body">
              {selectedEmployee && (
                <table className="table table-borderless">
                  <tbody>
                    <tr>
                      <th style={{ width: '40%' }}>社員名</th>
                      <td>{selectedEmployee.name}</td>
                    </tr>
                    <tr>
                      <th>部署</th>
                      <td>{selectedEmployee.department}</td>
                    </tr>
                    <tr>
                      <th>役職</th>
                      <td>{selectedEmployee.position}</td>
                    </tr>
                    <tr>
                      <th>LINE ID</th>
                      <td>{selectedEmployee.lineId || '-'}</td>
                    </tr>
                    <tr>
                      <th>LINE連携状況</th>
                      <td>
                        <span className={`badge bg-${selectedEmployee.status === '連携済' ? 'success' : 'warning'}`}>
                          {selectedEmployee.status}
                        </span>
                      </td>
                    </tr>
                  </tbody>
                </table>
              )}
            </div>
            <div className="modal-footer">
              <button type="button" className="btn btn-secondary" data-bs-dismiss="modal">閉じる</button>
              <button type="button" className="btn btn-primary">編集</button>
            </div>
          </div>
        </div>
      </div>
    </>
  )
}

