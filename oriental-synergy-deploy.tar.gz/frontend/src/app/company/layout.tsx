import React from 'react'
import CompanySidebar from '@/components/layout/CompanySidebar'
import Header from '@/components/layout/Header'
import Footer from '@/components/layout/Footer'

export default function CompanyLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <div className="admin-layout">
      <CompanySidebar />
      <div className="main-wrapper">
        <Header />
        <main className="main-content">
          {children}
        </main>
        <Footer />
      </div>
    </div>
  )
}

