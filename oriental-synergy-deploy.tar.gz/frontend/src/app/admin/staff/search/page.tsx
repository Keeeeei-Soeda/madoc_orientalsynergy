'use client'

import React, { useState } from 'react'
import Link from 'next/link'
import PageHeader from '@/components/common/PageHeader'

// モックデータ
const allStaff = [
  { 
    id: '1', 
    name: '山田花子', 
    rating: 4.8, 
    totalJobs: 150, 
    lastJobDate: '2024-12-20',
    skills: ['リンパマッサージ', 'アロマセラピー'], 
    area: '大阪',
    matchScore: 95
  },
  { 
    id: '2', 
    name: '佐藤美咲', 
    rating: 4.9, 
    totalJobs: 200, 
    lastJobDate: '2024-12-22',
    skills: ['整体', 'リフレクソロジー'], 
    area: '東京',
    matchScore: 92
  },
  { 
    id: '3', 
    name: '鈴木愛', 
    rating: 4.5, 
    totalJobs: 80, 
    lastJobDate: '2024-12-15',
    skills: ['ヘッドスパ', 'フットケア', 'リンパマッサージ'], 
    area: '大阪',
    matchScore: 88
  },
  { 
    id: '4', 
    name: '高橋麗子', 
    rating: 4.7, 
    totalJobs: 120, 
    lastJobDate: '2024-12-18',
    skills: ['リンパマッサージ', '整体'], 
    area: '名古屋',
    matchScore: 90
  },
]

export default function StaffSearchPage() {
  const [searchParams, setSearchParams] = useState({
    skills: [] as string[],
    minRating: '',
    area: '',
    sortBy: 'rating'
  })
  
  const [searchResults, setSearchResults] = useState(allStaff)
  
  const handleSearch = () => {
    let results = [...allStaff]
    
    // スキルフィルター
    if (searchParams.skills.length > 0) {
      results = results.filter(staff => 
        searchParams.skills.some(skill => staff.skills.includes(skill))
      )
    }
    
    // 評価フィルター
    if (searchParams.minRating) {
      results = results.filter(staff => 
        staff.rating >= parseFloat(searchParams.minRating)
      )
    }
    
    // エリアフィルター
    if (searchParams.area) {
      results = results.filter(staff => staff.area === searchParams.area)
    }
    
    // ソート
    results.sort((a, b) => {
      switch (searchParams.sortBy) {
        case 'rating':
          return b.rating - a.rating
        case 'jobs':
          return b.totalJobs - a.totalJobs
        case 'lastJobDate':
          return new Date(b.lastJobDate).getTime() - new Date(a.lastJobDate).getTime()
        default:
          return 0
      }
    })
    
    setSearchResults(results)
  }
  
  const toggleSkill = (skill: string) => {
    setSearchParams(prev => ({
      ...prev,
      skills: prev.skills.includes(skill)
        ? prev.skills.filter(s => s !== skill)
        : [...prev.skills, skill]
    }))
  }
  
  return (
    <>
      <PageHeader 
        title="スタッフ検索" 
        breadcrumbs={[
          { label: 'ダッシュボード', href: '/admin/dashboard' },
          { label: 'スタッフ管理', href: '/admin/staff' },
          { label: 'スタッフ検索' }
        ]}
      />
      
      <div className="row g-4">
        {/* 検索フォーム */}
        <div className="col-12 col-xl-3">
          <div className="card">
            <div className="card-header">
              <h5 className="mb-0">検索条件</h5>
            </div>
            <div className="card-body">
              {/* スキル選択 */}
              <div className="mb-4">
                <label className="form-label">スキル</label>
                <div className="d-flex flex-column gap-2">
                  {['リンパマッサージ', 'アロマセラピー', '整体', 'リフレクソロジー', 'ヘッドスパ', 'フットケア'].map((skill) => (
                    <div key={skill} className="form-check">
                      <input 
                        className="form-check-input" 
                        type="checkbox" 
                        id={skill}
                        checked={searchParams.skills.includes(skill)}
                        onChange={() => toggleSkill(skill)}
                      />
                      <label className="form-check-label" htmlFor={skill}>
                        {skill}
                      </label>
                    </div>
                  ))}
                </div>
              </div>
              
              {/* 評価 */}
              <div className="mb-4">
                <label className="form-label">最低評価</label>
                <select 
                  className="form-select"
                  value={searchParams.minRating}
                  onChange={(e) => setSearchParams({...searchParams, minRating: e.target.value})}
                >
                  <option value="">指定なし</option>
                  <option value="4.5">4.5以上</option>
                  <option value="4.0">4.0以上</option>
                  <option value="3.5">3.5以上</option>
                </select>
              </div>
              
              {/* エリア */}
              <div className="mb-4">
                <label className="form-label">エリア</label>
                <select 
                  className="form-select"
                  value={searchParams.area}
                  onChange={(e) => setSearchParams({...searchParams, area: e.target.value})}
                >
                  <option value="">すべて</option>
                  <option value="東京">東京</option>
                  <option value="大阪">大阪</option>
                  <option value="名古屋">名古屋</option>
                  <option value="福岡">福岡</option>
                </select>
              </div>
              
              {/* ソート */}
              <div className="mb-4">
                <label className="form-label">並び順</label>
                <select 
                  className="form-select"
                  value={searchParams.sortBy}
                  onChange={(e) => setSearchParams({...searchParams, sortBy: e.target.value})}
                >
                  <option value="rating">評価が高い順</option>
                  <option value="jobs">業務実績が多い順</option>
                  <option value="lastJobDate">最終業務日が新しい順</option>
                </select>
              </div>
              
              <button 
                className="btn btn-primary w-100"
                onClick={handleSearch}
              >
                <i className="bi bi-search me-2"></i>
                検索
              </button>
              
              <button 
                className="btn btn-outline-secondary w-100 mt-2"
                onClick={() => {
                  setSearchParams({ skills: [], minRating: '', area: '', sortBy: 'rating' })
                  setSearchResults(allStaff)
                }}
              >
                <i className="bi bi-arrow-counterclockwise me-2"></i>
                リセット
              </button>
            </div>
          </div>
        </div>
        
        {/* 検索結果 */}
        <div className="col-12 col-xl-9">
          <div className="card">
            <div className="card-header">
              <h5 className="mb-0">検索結果 ({searchResults.length}件)</h5>
            </div>
            <div className="card-body p-0">
              <div className="table-responsive">
                <table className="table table-hover mb-0">
                  <thead>
                    <tr>
                      <th>スタッフ名</th>
                      <th>評価</th>
                      <th>業務実績</th>
                      <th>最終業務日</th>
                      <th>スキル</th>
                      <th>エリア</th>
                      <th>マッチ度</th>
                      <th></th>
                    </tr>
                  </thead>
                  <tbody>
                    {searchResults.map((staff) => (
                      <tr key={staff.id}>
                        <td className="fw-bold">{staff.name}</td>
                        <td>
                          <i className="bi bi-star-fill text-warning me-1"></i>
                          {staff.rating.toFixed(1)}
                        </td>
                        <td>{staff.totalJobs}件</td>
                        <td>{staff.lastJobDate}</td>
                        <td>
                          <div className="d-flex flex-wrap gap-1">
                            {staff.skills.slice(0, 2).map((skill, idx) => (
                              <span key={idx} className="badge bg-light text-dark small">
                                {skill}
                              </span>
                            ))}
                            {staff.skills.length > 2 && (
                              <span className="badge bg-light text-dark small">
                                +{staff.skills.length - 2}
                              </span>
                            )}
                          </div>
                        </td>
                        <td>{staff.area}</td>
                        <td>
                          <div className="progress" style={{ height: '24px' }}>
                            <div 
                              className="progress-bar bg-success" 
                              role="progressbar" 
                              style={{ width: `${staff.matchScore}%` }}
                            >
                              {staff.matchScore}%
                            </div>
                          </div>
                        </td>
                        <td>
                          <div className="btn-group btn-group-sm">
                            <Link href={`/admin/staff/${staff.id}`} className="btn btn-outline-primary">
                              <i className="bi bi-eye"></i>
                            </Link>
                            <button className="btn btn-primary">
                              <i className="bi bi-person-plus-fill"></i>
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  )
}

