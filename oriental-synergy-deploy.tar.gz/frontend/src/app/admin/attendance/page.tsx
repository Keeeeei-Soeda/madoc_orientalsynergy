'use client'

import React, { useState } from 'react'
import Link from 'next/link'
import PageHeader from '@/components/common/PageHeader'

// モックデータ
const attendanceData = [
  {
    id: '1',
    staff: '山田花子',
    company: '株式会社サンプル',
    office: '梅田事業所',
    date: '2024-12-23',
    clockIn: '10:00',
    clockOut: '14:00',
    breakMinutes: 0,
    workHours: 4.0,
    workCount: 8,
    method: 'line',
    status: 'completed'
  },
  {
    id: '2',
    staff: '佐藤美咲',
    company: 'ABC株式会社',
    office: '難波事業所',
    date: '2024-12-23',
    clockIn: '09:30',
    clockOut: null,
    breakMinutes: 0,
    workHours: null,
    workCount: null,
    method: 'web',
    status: 'clocked_in'
  },
  {
    id: '3',
    staff: '鈴木愛',
    company: 'XYZ商事',
    office: '本社',
    date: '2024-12-22',
    clockIn: '14:00',
    clockOut: '18:00',
    breakMinutes: 30,
    workHours: 3.5,
    workCount: 6,
    method: 'line',
    status: 'completed'
  },
  {
    id: '4',
    staff: '高橋麗子',
    company: '〇〇物産',
    office: '大阪支店',
    date: '2024-12-22',
    clockIn: '10:00',
    clockOut: '15:00',
    breakMinutes: 0,
    workHours: 5.0,
    workCount: 10,
    method: 'web',
    status: 'verified'
  },
]

const statusConfig = {
  clocked_in: { label: '出勤中', color: 'info' },
  completed: { label: '退勤済み', color: 'success' },
  verified: { label: '確認済み', color: 'secondary' },
}

const methodConfig = {
  web: { label: 'Web', icon: 'bi-display' },
  line: { label: 'LINE', icon: 'bi-line' },
}

export default function AttendancePage() {
  const [searchTerm, setSearchTerm] = useState('')
  const [statusFilter, setStatusFilter] = useState('')
  
  const filteredAttendance = attendanceData.filter(attendance => {
    const matchesSearch = attendance.staff.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         attendance.company.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesStatus = !statusFilter || attendance.status === statusFilter
    return matchesSearch && matchesStatus
  })
  
  return (
    <>
      <PageHeader 
        title="勤怠管理" 
        breadcrumbs={[
          { label: 'ダッシュボード', href: '/admin/dashboard' },
          { label: '勤怠管理' }
        ]}
      />
      
      {/* 統計カード */}
      <div className="row g-3 mb-4">
        <div className="col-12 col-sm-6 col-xl-3">
          <div className="stat-card">
            <div className="stat-icon bg-info bg-opacity-10 text-info">
              <i className="bi bi-clock-history"></i>
            </div>
            <div className="stat-label">今日の出勤中</div>
            <div className="stat-value">3人</div>
          </div>
        </div>
        <div className="col-12 col-sm-6 col-xl-3">
          <div className="stat-card">
            <div className="stat-icon bg-success bg-opacity-10 text-success">
              <i className="bi bi-check-circle"></i>
            </div>
            <div className="stat-label">今日の退勤済み</div>
            <div className="stat-value">15人</div>
          </div>
        </div>
        <div className="col-12 col-sm-6 col-xl-3">
          <div className="stat-card">
            <div className="stat-icon bg-primary bg-opacity-10 text-primary">
              <i className="bi bi-hourglass-split"></i>
            </div>
            <div className="stat-label">今月の総勤務時間</div>
            <div className="stat-value">1,250h</div>
          </div>
        </div>
        <div className="col-12 col-sm-6 col-xl-3">
          <div className="stat-card">
            <div className="stat-icon bg-warning bg-opacity-10 text-warning">
              <i className="bi bi-exclamation-triangle"></i>
            </div>
            <div className="stat-label">未確認</div>
            <div className="stat-value">5件</div>
          </div>
        </div>
      </div>
      
      {/* 検索・フィルター */}
      <div className="card mb-4">
        <div className="card-body">
          <div className="row g-3">
            <div className="col-12 col-md-5">
              <div className="search-bar">
                <i className="bi bi-search search-icon"></i>
                <input 
                  type="text" 
                  className="form-control" 
                  placeholder="スタッフ名・企業名で検索..." 
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
            </div>
            <div className="col-12 col-md-3">
              <select 
                className="form-select"
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
              >
                <option value="">すべてのステータス</option>
                <option value="clocked_in">出勤中</option>
                <option value="completed">退勤済み</option>
                <option value="verified">確認済み</option>
              </select>
            </div>
            <div className="col-12 col-md-4">
              <div className="input-group">
                <input type="date" className="form-control" />
                <span className="input-group-text">〜</span>
                <input type="date" className="form-control" />
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* 勤怠一覧 */}
      <div className="card">
        <div className="card-header">
          <h5 className="mb-0">勤怠一覧 ({filteredAttendance.length}件)</h5>
        </div>
        <div className="card-body p-0">
          <div className="table-responsive">
            <table className="table table-hover mb-0">
              <thead>
                <tr>
                  <th>スタッフ</th>
                  <th>企業・事業所</th>
                  <th>日付</th>
                  <th>出勤</th>
                  <th>退勤</th>
                  <th>休憩</th>
                  <th>勤務時間</th>
                  <th>作業数</th>
                  <th>打刻方法</th>
                  <th>ステータス</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {filteredAttendance.map((attendance) => {
                  const statusConf = statusConfig[attendance.status as keyof typeof statusConfig]
                  const methodConf = methodConfig[attendance.method as keyof typeof methodConfig]
                  
                  return (
                    <tr key={attendance.id}>
                      <td className="fw-bold">{attendance.staff}</td>
                      <td>
                        <div className="fw-bold small">{attendance.company}</div>
                        <small className="text-muted">{attendance.office}</small>
                      </td>
                      <td>{attendance.date}</td>
                      <td>{attendance.clockIn}</td>
                      <td>{attendance.clockOut || '-'}</td>
                      <td>{attendance.breakMinutes ? `${attendance.breakMinutes}分` : '-'}</td>
                      <td className="fw-bold">
                        {attendance.workHours ? `${attendance.workHours}時間` : '-'}
                      </td>
                      <td>{attendance.workCount ? `${attendance.workCount}件` : '-'}</td>
                      <td>
                        <span className={`badge bg-${attendance.method === 'line' ? 'success' : 'primary'}`}>
                          <i className={`${methodConf.icon} me-1`}></i>
                          {methodConf.label}
                        </span>
                      </td>
                      <td>
                        <span className={`badge bg-${statusConf.color}`}>
                          {statusConf.label}
                        </span>
                      </td>
                      <td>
                        <div className="btn-group btn-group-sm">
                          <Link href={`/admin/attendance/${attendance.id}`} className="btn btn-outline-primary">
                            <i className="bi bi-eye"></i>
                          </Link>
                          {attendance.status === 'completed' && (
                            <button className="btn btn-outline-success">
                              <i className="bi bi-check-lg"></i>
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>
      
      {/* ページネーション */}
      <nav className="mt-4">
        <ul className="pagination justify-content-center">
          <li className="page-item disabled">
            <a className="page-link" href="#" aria-label="Previous">
              <span aria-hidden="true">&laquo;</span>
            </a>
          </li>
          <li className="page-item active"><a className="page-link" href="#">1</a></li>
          <li className="page-item"><a className="page-link" href="#">2</a></li>
          <li className="page-item"><a className="page-link" href="#">3</a></li>
          <li className="page-item">
            <a className="page-link" href="#" aria-label="Next">
              <span aria-hidden="true">&raquo;</span>
            </a>
          </li>
        </ul>
      </nav>
    </>
  )
}

