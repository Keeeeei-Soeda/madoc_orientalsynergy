'use client'

import React, { useState, useEffect } from 'react'
import Link from 'next/link'
import PageHeader from '@/components/common/PageHeader'
import { Reservation, ReservationStatus, getStatusLabel, getStatusBadgeClass } from '@/lib/api'

// モックデータ（認証機能実装までの仮データ）
const mockReservations: Reservation[] = [
  {
    id: 1,
    company_id: 1,
    office_name: '本社オフィス',
    office_address: '大阪府大阪市北区梅田1-1-1',
    reservation_date: '2026/01/15',
    start_time: '10:00',
    end_time: '12:00',
    staff_names: '山田花子, 佐藤美咲',
    employee_names: '田中部長, 鈴木課長',
    status: 'confirmed',
    notes: '定期契約',
    requirements: '2名派遣希望',
    created_at: '2026-01-01T00:00:00',
    updated_at: '2026-01-01T00:00:00',
  },
  {
    id: 2,
    company_id: 1,
    office_name: '本社オフィス',
    office_address: '大阪府大阪市北区梅田1-1-1',
    reservation_date: '2026/01/20',
    start_time: '14:00',
    end_time: '16:00',
    staff_names: '鈴木健太',
    employee_names: '佐藤主任',
    status: 'confirmed',
    notes: '定期契約',
    requirements: '1名派遣希望',
    created_at: '2026-01-02T00:00:00',
    updated_at: '2026-01-02T00:00:00',
  },
  {
    id: 3,
    company_id: 2,
    office_name: '大阪工場',
    office_address: '大阪府大阪市中央区難波2-2-2',
    reservation_date: '2026/01/25',
    start_time: '09:00',
    end_time: '11:00',
    staff_names: '',
    employee_names: '高橋工場長',
    status: 'pending',
    notes: '新規予約',
    requirements: '2名派遣希望、ベテラン優先',
    created_at: '2026-01-05T00:00:00',
    updated_at: '2026-01-05T00:00:00',
  },
  {
    id: 4,
    company_id: 1,
    office_name: '本社オフィス',
    office_address: '大阪府大阪市北区梅田1-1-1',
    reservation_date: '2025/12/20',
    start_time: '10:00',
    end_time: '12:00',
    staff_names: '山田花子, 佐藤美咲',
    employee_names: '田中部長, 鈴木課長',
    status: 'completed',
    notes: '完了済み',
    requirements: '2名派遣希望',
    created_at: '2025-12-10T00:00:00',
    updated_at: '2025-12-20T00:00:00',
  },
]

export default function ReservationsPage() {
  const [reservations, setReservations] = useState<Reservation[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [statusFilter, setStatusFilter] = useState<ReservationStatus | ''>('')
  const [searchTerm, setSearchTerm] = useState('')
  
  // データ取得（モックデータを使用）
  useEffect(() => {
    // 認証機能実装までは、モックデータを表示
    setTimeout(() => {
      setReservations(mockReservations)
      setLoading(false)
    }, 500)
    
    /* API連携版（認証実装後に使用）
    const fetchReservations = async () => {
      try {
        setLoading(true)
        const data = await reservationsApi.getAll()
        setReservations(data)
      } catch (err) {
        setError(err instanceof Error ? err.message : '予約データの取得に失敗しました')
        console.error('予約データ取得エラー:', err)
      } finally {
        setLoading(false)
      }
    }
    fetchReservations()
    */
  }, [])
  
  const filteredReservations = reservations.filter(reservation => {
    const matchesStatus = !statusFilter || reservation.status === statusFilter
    const matchesSearch = reservation.office_name.toLowerCase().includes(searchTerm.toLowerCase())
    return matchesStatus && matchesSearch
  })
  
  // ローディング表示
  if (loading) {
    return (
      <>
        <PageHeader 
          title="予約管理" 
          breadcrumbs={[
            { label: 'ダッシュボード', href: '/admin/dashboard' },
            { label: '予約管理' }
          ]}
        />
        <div className="text-center py-5">
          <div className="spinner-border text-primary" role="status">
            <span className="visually-hidden">読み込み中...</span>
          </div>
        </div>
      </>
    )
  }
  
  // エラー表示
  if (error) {
    return (
      <>
        <PageHeader 
          title="予約管理" 
          breadcrumbs={[
            { label: 'ダッシュボード', href: '/admin/dashboard' },
            { label: '予約管理' }
          ]}
        />
        <div className="alert alert-danger" role="alert">
          <i className="bi bi-exclamation-triangle me-2"></i>
          {error}
        </div>
      </>
    )
  }
  
  return (
    <>
      <PageHeader 
        title="予約管理" 
        breadcrumbs={[
          { label: 'ダッシュボード', href: '/admin/dashboard' },
          { label: '予約管理' }
        ]}
        action={
          <div className="d-flex gap-2">
            <Link href="/admin/reservations/calendar" className="btn btn-outline-primary">
              <i className="bi bi-calendar-week me-2"></i>
              カレンダー表示
            </Link>
          </div>
        }
      />
      
      {/* 検索・フィルター */}
      <div className="card mb-4">
        <div className="card-body">
          <div className="row g-3">
            <div className="col-12 col-md-6">
              <div className="search-bar">
                <i className="bi bi-search search-icon"></i>
                <input 
                  type="text" 
                  className="form-control" 
                  placeholder="事業所名で検索..." 
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
            </div>
            <div className="col-12 col-md-3">
              <select 
                className="form-select"
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value as ReservationStatus | '')}
              >
                <option value="">すべてのステータス</option>
                <option value="pending">未確認</option>
                <option value="confirmed">確定</option>
                <option value="completed">完了</option>
                <option value="cancelled">キャンセル</option>
                <option value="evaluated">評価済み</option>
              </select>
            </div>
          </div>
        </div>
      </div>
      
      {/* 予約一覧 */}
      <div className="card">
        <div className="card-header">
          <h5 className="mb-0">予約一覧 ({filteredReservations.length}件)</h5>
        </div>
        <div className="card-body p-0">
          <div className="table-responsive">
            <table className="table table-hover mb-0">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>事業所</th>
                  <th>住所</th>
                  <th>日時</th>
                  <th>スタッフ</th>
                  <th>ステータス</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {filteredReservations.map((reservation) => {
                  return (
                    <tr key={reservation.id}>
                      <td className="fw-bold">#{reservation.id}</td>
                      <td>
                        <div className="fw-bold">{reservation.office_name}</div>
                      </td>
                      <td>
                        <small className="text-muted">{reservation.office_address}</small>
                      </td>
                      <td>
                        <div>{reservation.reservation_date}</div>
                        <small className="text-muted">{reservation.start_time}〜{reservation.end_time}</small>
                      </td>
                      <td>
                        <small className="text-muted">
                          {reservation.staff_names || '未アサイン'}
                        </small>
                      </td>
                      <td>
                        <span className={`badge ${getStatusBadgeClass(reservation.status)}`}>
                          {getStatusLabel(reservation.status)}
                        </span>
                      </td>
                      <td>
                        <div className="btn-group btn-group-sm">
                          <Link href={`/admin/reservations/${reservation.id}`} className="btn btn-outline-primary">
                            <i className="bi bi-eye"></i>
                          </Link>
                          <Link href={`/admin/reservations/${reservation.id}/edit`} className="btn btn-outline-secondary">
                            <i className="bi bi-pencil"></i>
                          </Link>
                        </div>
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </>
  )
}

