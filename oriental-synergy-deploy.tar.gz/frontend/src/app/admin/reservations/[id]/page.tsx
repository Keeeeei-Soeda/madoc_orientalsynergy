'use client'

import React, { useState, useEffect } from 'react'
import { useParams, useRouter } from 'next/navigation'
import Link from 'next/link'
import PageHeader from '@/components/common/PageHeader'
import { reservationsApi, Reservation, getStatusLabel, getStatusBadgeClass } from '@/lib/api'

export default function ReservationDetailPage() {
  const params = useParams()
  const router = useRouter()
  const reservationId = parseInt(params.id as string)
  
  const [reservation, setReservation] = useState<Reservation | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  
  // データ取得
  useEffect(() => {
    const fetchReservation = async () => {
      try {
        setLoading(true)
        const data = await reservationsApi.getById(reservationId)
        setReservation(data)
      } catch (err) {
        setError(err instanceof Error ? err.message : '予約データの取得に失敗しました')
        console.error('予約データ取得エラー:', err)
      } finally {
        setLoading(false)
      }
    }
    
    if (reservationId) {
      fetchReservation()
    }
  }, [reservationId])
  
  // 削除処理
  const handleDelete = async () => {
    if (!confirm('この予約を削除してもよろしいですか？')) {
      return
    }
    
    try {
      await reservationsApi.delete(reservationId)
      alert('予約を削除しました')
      router.push('/admin/reservations')
    } catch (err) {
      alert('削除に失敗しました: ' + (err instanceof Error ? err.message : ''))
    }
  }
  
  // ステータス更新
  const handleStatusUpdate = async (newStatus: string) => {
    if (!reservation) return
    
    try {
      const updated = await reservationsApi.update(reservationId, { 
        status: newStatus as any 
      })
      setReservation(updated)
      alert('ステータスを更新しました')
    } catch (err) {
      alert('更新に失敗しました: ' + (err instanceof Error ? err.message : ''))
    }
  }
  
  // ローディング表示
  if (loading) {
    return (
      <>
        <PageHeader 
          title="予約詳細" 
          breadcrumbs={[
            { label: 'ダッシュボード', href: '/admin/dashboard' },
            { label: '予約管理', href: '/admin/reservations' },
            { label: '予約詳細' }
          ]}
        />
        <div className="text-center py-5">
          <div className="spinner-border text-primary" role="status">
            <span className="visually-hidden">読み込み中...</span>
          </div>
        </div>
      </>
    )
  }
  
  // エラー表示
  if (error || !reservation) {
    return (
      <>
        <PageHeader 
          title="予約詳細" 
          breadcrumbs={[
            { label: 'ダッシュボード', href: '/admin/dashboard' },
            { label: '予約管理', href: '/admin/reservations' },
            { label: '予約詳細' }
          ]}
        />
        <div className="alert alert-danger" role="alert">
          <i className="bi bi-exclamation-triangle me-2"></i>
          {error || '予約が見つかりませんでした'}
        </div>
      </>
    )
  }
  
  return (
    <>
      <PageHeader 
        title={`予約詳細 #${reservation.id}`}
        breadcrumbs={[
          { label: 'ダッシュボード', href: '/admin/dashboard' },
          { label: '予約管理', href: '/admin/reservations' },
          { label: `予約 #${reservation.id}` }
        ]}
        action={
          <div className="d-flex gap-2">
            <Link 
              href={`/admin/reservations/${reservation.id}/edit`} 
              className="btn btn-primary"
            >
              <i className="bi bi-pencil me-2"></i>
              編集
            </Link>
            <button 
              onClick={handleDelete}
              className="btn btn-danger"
            >
              <i className="bi bi-trash me-2"></i>
              削除
            </button>
          </div>
        }
      />
      
      <div className="row g-4">
        {/* 基本情報 */}
        <div className="col-12 col-lg-8">
          <div className="card mb-4">
            <div className="card-header">
              <h5 className="mb-0">基本情報</h5>
            </div>
            <div className="card-body">
              <div className="row g-3">
                <div className="col-12 col-md-6">
                  <label className="form-label text-muted">事業所名</label>
                  <p className="fw-bold">{reservation.office_name}</p>
                </div>
                <div className="col-12 col-md-6">
                  <label className="form-label text-muted">企業ID</label>
                  <p className="fw-bold">
                    <Link href={`/admin/companies/${reservation.company_id}`} className="text-decoration-none">
                      #{reservation.company_id}
                    </Link>
                  </p>
                </div>
                <div className="col-12">
                  <label className="form-label text-muted">事業所住所</label>
                  <p>{reservation.office_address || '未設定'}</p>
                </div>
                <div className="col-12 col-md-4">
                  <label className="form-label text-muted">予約日</label>
                  <p className="fw-bold">
                    <i className="bi bi-calendar3 me-2 text-primary"></i>
                    {reservation.reservation_date}
                  </p>
                </div>
                <div className="col-12 col-md-4">
                  <label className="form-label text-muted">開始時刻</label>
                  <p className="fw-bold">
                    <i className="bi bi-clock me-2 text-success"></i>
                    {reservation.start_time}
                  </p>
                </div>
                <div className="col-12 col-md-4">
                  <label className="form-label text-muted">終了時刻</label>
                  <p className="fw-bold">
                    <i className="bi bi-clock-fill me-2 text-danger"></i>
                    {reservation.end_time}
                  </p>
                </div>
              </div>
            </div>
          </div>
          
          {/* スタッフ・社員情報 */}
          <div className="card mb-4">
            <div className="card-header">
              <h5 className="mb-0">スタッフ・社員情報</h5>
            </div>
            <div className="card-body">
              <div className="row g-3">
                <div className="col-12 col-md-6">
                  <label className="form-label text-muted">担当スタッフ</label>
                  <p>{reservation.staff_names || '未アサイン'}</p>
                </div>
                <div className="col-12 col-md-6">
                  <label className="form-label text-muted">対象社員</label>
                  <p>{reservation.employee_names || '未設定'}</p>
                </div>
              </div>
            </div>
          </div>
          
          {/* 備考・要望 */}
          <div className="card">
            <div className="card-header">
              <h5 className="mb-0">備考・要望</h5>
            </div>
            <div className="card-body">
              <div className="mb-3">
                <label className="form-label text-muted">備考</label>
                <p>{reservation.notes || 'なし'}</p>
              </div>
              <div>
                <label className="form-label text-muted">要望</label>
                <p>{reservation.requirements || 'なし'}</p>
              </div>
            </div>
          </div>
        </div>
        
        {/* サイドバー */}
        <div className="col-12 col-lg-4">
          {/* ステータス */}
          <div className="card mb-4">
            <div className="card-header">
              <h5 className="mb-0">ステータス</h5>
            </div>
            <div className="card-body">
              <div className="mb-3">
                <span className={`badge ${getStatusBadgeClass(reservation.status)} fs-6`}>
                  {getStatusLabel(reservation.status)}
                </span>
              </div>
              <div className="d-grid gap-2">
                {reservation.status === 'pending' && (
                  <button 
                    onClick={() => handleStatusUpdate('confirmed')}
                    className="btn btn-success"
                  >
                    確定する
                  </button>
                )}
                {reservation.status === 'confirmed' && (
                  <button 
                    onClick={() => handleStatusUpdate('completed')}
                    className="btn btn-primary"
                  >
                    完了にする
                  </button>
                )}
                {(reservation.status === 'pending' || reservation.status === 'confirmed') && (
                  <button 
                    onClick={() => handleStatusUpdate('cancelled')}
                    className="btn btn-outline-danger"
                  >
                    キャンセル
                  </button>
                )}
              </div>
            </div>
          </div>
          
          {/* タイムスタンプ */}
          <div className="card">
            <div className="card-header">
              <h5 className="mb-0">作成・更新情報</h5>
            </div>
            <div className="card-body">
              <div className="mb-3">
                <label className="form-label text-muted small">作成日時</label>
                <p className="small">{new Date(reservation.created_at).toLocaleString('ja-JP')}</p>
              </div>
              <div>
                <label className="form-label text-muted small">更新日時</label>
                <p className="small">{new Date(reservation.updated_at).toLocaleString('ja-JP')}</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  )
}




