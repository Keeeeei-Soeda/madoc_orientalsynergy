'use client'

import React from 'react'

export default function Header() {
  return (
    <header className="header d-flex align-items-center justify-content-between">
      <div className="d-flex align-items-center">
        <h5 className="mb-0">オリエンタルシナジー</h5>
      </div>
      
      <div className="d-flex align-items-center gap-3">
        {/* 通知アイコン */}
        <div className="position-relative">
          <button className="btn btn-sm btn-light">
            <i className="bi bi-bell"></i>
            <span className="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
              3
            </span>
          </button>
        </div>
        
        {/* ユーザーメニュー */}
        <div className="dropdown">
          <button 
            className="btn btn-sm btn-light dropdown-toggle" 
            type="button" 
            data-bs-toggle="dropdown"
          >
            <i className="bi bi-person-circle me-2"></i>
            管理者
          </button>
          <ul className="dropdown-menu dropdown-menu-end">
            <li><a className="dropdown-item" href="#"><i className="bi bi-person me-2"></i>プロフィール</a></li>
            <li><a className="dropdown-item" href="#"><i className="bi bi-gear me-2"></i>設定</a></li>
            <li><hr className="dropdown-divider" /></li>
            <li><a className="dropdown-item text-danger" href="#"><i className="bi bi-box-arrow-right me-2"></i>ログアウト</a></li>
          </ul>
        </div>
      </div>
    </header>
  )
}

