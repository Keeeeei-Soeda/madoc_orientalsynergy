/**
 * APIクライアント
 * バックエンドAPIとの通信を行う
 */

const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api/v1';

/**
 * APIリクエストのオプション型
 */
interface RequestOptions extends RequestInit {
  token?: string;
}

/**
 * APIエラー
 */
export class ApiError extends Error {
  constructor(
    message: string,
    public status: number,
    public data?: any
  ) {
    super(message);
    this.name = 'ApiError';
  }
}

/**
 * APIリクエストを送信する共通関数
 */
async function request<T>(
  endpoint: string,
  options: RequestOptions = {}
): Promise<T> {
  const { token, ...fetchOptions } = options;

  const headers: HeadersInit = {
    'Content-Type': 'application/json',
    ...fetchOptions.headers,
  };

  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  const response = await fetch(`${API_BASE_URL}${endpoint}`, {
    ...fetchOptions,
    headers,
  });

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({}));
    throw new ApiError(
      errorData.detail || `API Error: ${response.status}`,
      response.status,
      errorData
    );
  }

  return response.json();
}

// ========================================
// ユーザーAPI
// ========================================

export interface User {
  id: number;
  email: string;
  full_name: string;
  role: string;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface UserCreate {
  email: string;
  password: string;
  full_name: string;
  role: string;
}

export const usersApi = {
  getAll: (skip = 0, limit = 100) =>
    request<User[]>(`/users?skip=${skip}&limit=${limit}`),
  getById: (id: number) => request<User>(`/users/${id}`),
  create: (data: UserCreate) =>
    request<User>('/users', {
      method: 'POST',
      body: JSON.stringify(data),
    }),
  update: (id: number, data: Partial<User>) =>
    request<User>(`/users/${id}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    }),
  delete: (id: number) =>
    request<void>(`/users/${id}`, {
      method: 'DELETE',
    }),
};

// ========================================
// 企業API
// ========================================

export interface Company {
  id: number;
  user_id: number;
  company_name: string;
  address: string;
  phone: string;
  representative_name: string;
  contract_start_date: string;
  contract_end_date?: string;
  usage_status: string;
  line_id?: string;
  notes?: string;
  created_at: string;
  updated_at: string;
}

export interface CompanyCreate {
  user_id: number;
  company_name: string;
  address: string;
  phone: string;
  representative_name: string;
  contract_start_date: string;
  contract_end_date?: string;
  usage_status?: string;
  line_id?: string;
  notes?: string;
}

export const companiesApi = {
  getAll: (skip = 0, limit = 100) =>
    request<Company[]>(`/companies?skip=${skip}&limit=${limit}`),
  getById: (id: number) => request<Company>(`/companies/${id}`),
  create: (data: CompanyCreate) =>
    request<Company>('/companies', {
      method: 'POST',
      body: JSON.stringify(data),
    }),
  update: (id: number, data: Partial<Company>) =>
    request<Company>(`/companies/${id}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    }),
  delete: (id: number) =>
    request<void>(`/companies/${id}`, {
      method: 'DELETE',
    }),
};

// ========================================
// スタッフAPI
// ========================================

export interface Staff {
  id: number;
  user_id: number;
  name: string;
  phone: string;
  address: string;
  bank_account: string;
  qualifications: string;
  available_days: string;
  line_id?: string;
  is_available: boolean;
  rating: number;
  notes?: string;
  created_at: string;
  updated_at: string;
}

export interface StaffCreate {
  user_id: number;
  name: string;
  phone: string;
  address: string;
  bank_account: string;
  qualifications: string;
  available_days: string;
  line_id?: string;
  is_available?: boolean;
  rating?: number;
  notes?: string;
}

export const staffApi = {
  getAll: (skip = 0, limit = 100) =>
    request<Staff[]>(`/staff?skip=${skip}&limit=${limit}`),
  getById: (id: number) => request<Staff>(`/staff/${id}`),
  create: (data: StaffCreate) =>
    request<Staff>('/staff', {
      method: 'POST',
      body: JSON.stringify(data),
    }),
  update: (id: number, data: Partial<Staff>) =>
    request<Staff>(`/staff/${id}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    }),
  delete: (id: number) =>
    request<void>(`/staff/${id}`, {
      method: 'DELETE',
    }),
};

// ========================================
// 予約API
// ========================================

export type ReservationStatus = 'pending' | 'confirmed' | 'completed' | 'cancelled' | 'evaluated';

export interface Reservation {
  id: number;
  company_id: number;
  office_name: string;
  office_address?: string;
  reservation_date: string;
  start_time: string;
  end_time: string;
  staff_names?: string;
  employee_names?: string;
  status: ReservationStatus;
  notes?: string;
  requirements?: string;
  created_at: string;
  updated_at: string;
}

export interface ReservationCreate {
  company_id: number;
  office_name: string;
  office_address?: string;
  reservation_date: string;
  start_time: string;
  end_time: string;
  staff_names?: string;
  employee_names?: string;
  status?: ReservationStatus;
  notes?: string;
  requirements?: string;
}

export const reservationsApi = {
  getAll: (params?: { skip?: number; limit?: number; status?: ReservationStatus; company_id?: number }) => {
    const queryParams = new URLSearchParams();
    if (params?.skip !== undefined) queryParams.append('skip', params.skip.toString());
    if (params?.limit !== undefined) queryParams.append('limit', params.limit.toString());
    if (params?.status) queryParams.append('status', params.status);
    if (params?.company_id) queryParams.append('company_id', params.company_id.toString());
    
    const queryString = queryParams.toString();
    return request<Reservation[]>(`/reservations${queryString ? '?' + queryString : ''}`);
  },
  getById: (id: number) => request<Reservation>(`/reservations/${id}`),
  create: (data: ReservationCreate) =>
    request<Reservation>('/reservations', {
      method: 'POST',
      body: JSON.stringify(data),
    }),
  update: (id: number, data: Partial<Reservation>) =>
    request<Reservation>(`/reservations/${id}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    }),
  delete: (id: number) =>
    request<void>(`/reservations/${id}`, {
      method: 'DELETE',
    }),
};

/**
 * ステータスの日本語ラベルを取得
 */
export function getStatusLabel(status: ReservationStatus): string {
  const labels: Record<ReservationStatus, string> = {
    pending: '未確認',
    confirmed: '確定',
    completed: '完了',
    cancelled: 'キャンセル',
    evaluated: '評価済み',
  };
  return labels[status] || status;
}

/**
 * ステータスのバッジクラスを取得
 */
export function getStatusBadgeClass(status: ReservationStatus): string {
  const classes: Record<ReservationStatus, string> = {
    pending: 'bg-warning text-dark',
    confirmed: 'bg-primary',
    completed: 'bg-success',
    cancelled: 'bg-secondary',
    evaluated: 'bg-info',
  };
  return classes[status] || 'bg-secondary';
}




